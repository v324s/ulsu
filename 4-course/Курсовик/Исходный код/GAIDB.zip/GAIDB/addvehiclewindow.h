#ifndef ADDVEHICLEWINDOW_H
#define ADDVEHICLEWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonObject>
#include <QJsonDocument>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QMessageBox>
#include <QString>

namespace Ui {
class AddVehicleWindow;
}

class AddVehicleWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AddVehicleWindow(QWidget *parent, const QString &token, int id = -1, const QString &make = "", const QString &model = "", const QString &type = "", const QString &stateNumber = "", const QString &engineNumber = "", const QString &bodyNumber = "", const QString &owner = "", int horsepower = 0);
//    explicit AddVehicleWindow(QWidget *parent = nullptr, const QString &token = "");
    ~AddVehicleWindow();

    void setWindowTitle(const QString &title);
    void setSubmitButtonText(const QString &text);

private slots:
    void onSubmitButtonClicked();
//    void onSubmitButtonClicked();
    void onNetworkReplyFinished();

signals:
    void vehicleAdded();


private:
    Ui::AddVehicleWindow *ui;
    QString authToken;
    QNetworkAccessManager *networkManager;

    QLineEdit *idField;
    QLineEdit *makeField;
    QLineEdit *modelField;
    QLineEdit *typeField;
    QLineEdit *stateNumberField;
    QLineEdit *numberEngineField;
    QLineEdit *numberBodyField;
    QLineEdit *ownerField;
    QLineEdit *horsepowerField;
    QPushButton *submitButton;
     int vehicleId;
};

#endif // ADDVEHICLEWINDOW_H
