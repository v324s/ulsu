#include "vehiclewindow.h"
#include "ui_vehiclewindow.h"
#include "addvehiclewindow.h"
#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QHeaderView>
#include <QModelIndex>
#include <QDebug>

VehicleWindow::VehicleWindow(QWidget *parent, const QString &token, const QJsonObject &userPermissions) :
    QMainWindow(parent),
    ui(new Ui::VehicleWindow),
    authToken(token),
    permissions(userPermissions),
    networkManager(new QNetworkAccessManager(this))
{
    ui->setupUi(this);

    // Инициализация виджетов
    tableView = new QTableView(this);
    addButton = new QPushButton("Добавить", this);
    deleteButton = new QPushButton("Удалить", this);
    editButton = new QPushButton("Изменить", this);

    // Установка прав доступа

    addButton->setEnabled(permissions.value("can_vehicle_insert").toInt() == 1);
    deleteButton->setEnabled(permissions.value("can_vehicle_delete").toInt() == 1);
    editButton->setEnabled(permissions.value("can_vehicle_update").toInt() == 1);

    // Размещение виджетов
    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(tableView);
    layout->addWidget(addButton);
    layout->addWidget(deleteButton);
    layout->addWidget(editButton);

    QWidget *container = new QWidget;
    container->setLayout(layout);
    setCentralWidget(container);

    // Подключение слотов к кнопкам
    connect(addButton, &QPushButton::clicked, this, &VehicleWindow::onAddButtonClicked);
    connect(deleteButton, &QPushButton::clicked, this, &VehicleWindow::onDeleteButtonClicked);
    connect(editButton, &QPushButton::clicked, this, &VehicleWindow::onEditButtonClicked);

    // Выполнение запроса к API для получения данных
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

    QJsonObject postData;
    postData["method"] = "getVehicles";


    QNetworkReply *reply = networkManager->post(request, QJsonDocument(postData).toJson());
    connect(reply, &QNetworkReply::finished, this, &VehicleWindow::onNetworkReplyFinished);
}

VehicleWindow::~VehicleWindow()
{
    delete ui;
}

void VehicleWindow::onAddButtonClicked()
{
    // Логика добавления записи
    AddVehicleWindow *addWindow = new AddVehicleWindow(this, authToken);
    connect(addWindow, &AddVehicleWindow::vehicleAdded, this, &VehicleWindow::updateTable);
    addWindow->show();
}

void VehicleWindow::onDeleteButtonClicked()
{
    // Логика удаления записи
    QModelIndexList selection = tableView->selectionModel()->selectedRows();
        if (selection.isEmpty()) {
            QMessageBox::warning(this, "Ошибка", "Выберите строку для удаления.");
            return;
        }

        int row = selection.first().row();
        QStandardItemModel *model = qobject_cast<QStandardItemModel*>(tableView->model());
        int id = model->item(row, 0)->text().toInt();

        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "Подтверждение удаления",
                                      "Вы уверены, что хотите удалить строку #" + QString::number(id) + "?",
                                      QMessageBox::Yes|QMessageBox::No);

        if (reply == QMessageBox::Yes) {
            QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
            request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
            request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

            QJsonObject postData;
            postData["method"] = "deleteVehicle";
            postData["id"] = id;

            QNetworkReply *networkReply = networkManager->post(request, QJsonDocument(postData).toJson());
            connect(networkReply, &QNetworkReply::finished, this, &VehicleWindow::onDeleteNetworkReplyFinished);
        }
}

void VehicleWindow::onEditButtonClicked()
{
    // Логика редактирования записи
    QModelIndexList selectedRows = tableView->selectionModel()->selectedRows();
        if (selectedRows.isEmpty()) {
            QMessageBox::warning(this, "Ошибка", "Пожалуйста, выберите строку для редактирования.");
            return;
        }

        int selectedRow = selectedRows.first().row();

        QStandardItemModel *model = qobject_cast<QStandardItemModel*>(tableView->model());
        if (!model) {
            QMessageBox::warning(this, "Ошибка", "Невозможно получить модель данных.");
            return;
        }

        int id = model->item(selectedRow, 0)->text().toInt();
        QString make = model->item(selectedRow, 1)->text();
        QString modelStr = model->item(selectedRow, 2)->text();
        QString type = model->item(selectedRow, 3)->text();
        QString stateNumber = model->item(selectedRow, 4)->text();
        QString engineNumber = model->item(selectedRow, 5)->text();
        QString bodyNumber = model->item(selectedRow, 6)->text();
        QString owner = model->item(selectedRow, 7)->text();
        int horsepower = model->item(selectedRow, 8)->text().toInt();

        AddVehicleWindow *editWindow = new AddVehicleWindow(this, authToken, id, make, modelStr, type, stateNumber, engineNumber, bodyNumber, owner, horsepower);
        editWindow->setWindowTitle("Редактировать запись");
        editWindow->setSubmitButtonText("Изменить");
        connect(editWindow, &AddVehicleWindow::vehicleAdded, this, &VehicleWindow::updateTable);
        editWindow->show();
}

void VehicleWindow::updateTable()
{
    // Обновление таблицы
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

    QJsonObject postData;
    postData["method"] = "getVehicles";

    QNetworkReply *reply = networkManager->post(request, QJsonDocument(postData).toJson());
    connect(reply, &QNetworkReply::finished, this, &VehicleWindow::onNetworkReplyFinished);
}

void VehicleWindow::onNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
        if (reply->error() == QNetworkReply::NoError) {
            // Обработка успешного ответа и заполнение таблицы
            QByteArray response = reply->readAll();
            QJsonDocument jsonResponse = QJsonDocument::fromJson(response);
            QJsonArray jsonArray = jsonResponse.array();

            // Преобразование jsonArray в данные для таблицы
            QStandardItemModel *model = new QStandardItemModel(jsonArray.size(), 9, this);

            // Установка заголовков
            model->setHeaderData(0, Qt::Horizontal, "ID");
            model->setHeaderData(1, Qt::Horizontal, "Марка");
            model->setHeaderData(2, Qt::Horizontal, "Модель");
            model->setHeaderData(3, Qt::Horizontal, "Тип кузова");
            model->setHeaderData(4, Qt::Horizontal, "Гос. Номер");
            model->setHeaderData(5, Qt::Horizontal, "Номер двигателя");
            model->setHeaderData(6, Qt::Horizontal, "Номер кузова");
            model->setHeaderData(7, Qt::Horizontal, "Владелец");
            model->setHeaderData(8, Qt::Horizontal, "Мощность двигателя (л.с.)");

            // Заполнение модели данными
            for (int i = 0; i < jsonArray.size(); ++i) {
                QJsonObject jsonObject = jsonArray[i].toObject();
                model->setItem(i, 0, new QStandardItem(QString::number(jsonObject["id"].toInt())));
                model->setItem(i, 1, new QStandardItem(jsonObject["make"].toString()));
                model->setItem(i, 2, new QStandardItem(jsonObject["model"].toString()));
                model->setItem(i, 3, new QStandardItem(jsonObject["type"].toString()));
                model->setItem(i, 4, new QStandardItem(jsonObject["state_number"].toString()));
                model->setItem(i, 5, new QStandardItem(jsonObject["number_engine"].toString()));
                model->setItem(i, 6, new QStandardItem(jsonObject["number_body"].toString()));
                model->setItem(i, 7, new QStandardItem(QString::number(jsonObject["owner"].toInt())));
                model->setItem(i, 8, new QStandardItem(QString::number(jsonObject["horsepower"].toInt())));
            }

            tableView->setModel(model);
        } else {
            // Обработка ошибки
            QMessageBox::warning(this, "Ошибка", "Не удалось получить данные: " + reply->errorString());
        }
    reply->deleteLater();
}
void VehicleWindow::onDeleteNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (reply->error() == QNetworkReply::NoError) {
        // Успешное удаление
        QMessageBox::information(this, "Успех", "Строка успешно удалена.");
        updateTable();
    } else {
        // Обработка ошибки
        QMessageBox::warning(this, "Ошибка", "Не удалось удалить строку: " + reply->errorString());
    }
    reply->deleteLater();
}
