#include "adduserwindow.h"
#include "ui_adduserwindow.h"

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMessageBox>

AddUserWindow::AddUserWindow(QWidget *parent, const QString &token, int id, const QString &name, const QString &lname, const QString &login, const QString &pass, const bool &cps, const bool &cpd, const bool &cpi, const bool &cpu, const bool &cts, const bool &ctd, const bool &cti, const bool &ctu, const bool &cvs, const bool &cvd, const bool &cvi, const bool &cvu, const bool &cus, const bool &cud, const bool &cui, const bool &cuu) :
    QMainWindow(parent),
    ui(new Ui::AddUserWindow),
    authToken(token),
    networkManager(new QNetworkAccessManager(this)),
    userId(id)
{
    ui->setupUi(this);

    nameField = new QLineEdit(this);
    lnameField = new QLineEdit(this);
    loginField = new QLineEdit(this);
    passField = new QLineEdit(this);
    cpsField = new QCheckBox(this);
    cpdField = new QCheckBox(this);
    cpiField = new QCheckBox(this);
    cpuField = new QCheckBox(this);
    ctsField = new QCheckBox(this);
    ctdField = new QCheckBox(this);
    ctiField = new QCheckBox(this);
    ctuField = new QCheckBox(this);
    cvsField = new QCheckBox(this);
    cvdField = new QCheckBox(this);
    cviField = new QCheckBox(this);
    cvuField = new QCheckBox(this);
    cusField = new QCheckBox(this);
    cudField = new QCheckBox(this);
    cuiField = new QCheckBox(this);
    cuuField = new QCheckBox(this);
    submitButton = new QPushButton("Добавить", this);

    if (userId != -1) {
        idField = new QLineEdit(this);
        idField->setText(QString(id));
        idField->setEnabled(false);
        // Устанавливаем значения в поля формы
        nameField->setText(name);
        lnameField->setText(lname);
        loginField->setText(login);
        cpsField->setCheckState(Qt::CheckState(cps));
        cpsField->setCheckState(Qt::CheckState(cps));
        cpdField->setCheckState(Qt::CheckState(cpd));
        cpiField->setCheckState(Qt::CheckState(cpi));
        cpuField->setCheckState(Qt::CheckState(cpu));
        ctsField->setCheckState(Qt::CheckState(cts));
        ctdField->setCheckState(Qt::CheckState(ctd));
        ctiField->setCheckState(Qt::CheckState(cti));
        ctuField->setCheckState(Qt::CheckState(ctu));
        cvsField->setCheckState(Qt::CheckState(cvs));
        cvdField->setCheckState(Qt::CheckState(cvd));
        cviField->setCheckState(Qt::CheckState(cvi));
        cvuField->setCheckState(Qt::CheckState(cvu));
        cusField->setCheckState(Qt::CheckState(cus));
        cudField->setCheckState(Qt::CheckState(cud));
        cuiField->setCheckState(Qt::CheckState(cui));
        cuuField->setCheckState(Qt::CheckState(cuu));

        submitButton->setText("Изменить");
    }


    QFormLayout *formLayout = new QFormLayout;
//    formLayout->addRow("ID", idField);
    formLayout->addRow("Имя", nameField);
    formLayout->addRow("Фамилия", lnameField);
    formLayout->addRow("Логин", loginField);
    formLayout->addRow("Пароль", passField);
    formLayout->addRow("Люди | Смотреть", cpsField);
    formLayout->addRow("Люди | Удалять", cpdField);
    formLayout->addRow("Люди | Добавлять", cpiField);
    formLayout->addRow("Люди | Изменять", cpuField);

    formLayout->addRow("Тех.осмотры | Смотреть", ctsField);
    formLayout->addRow("Тех.осмотры | Удалять", ctdField);
    formLayout->addRow("Тех.осмотры | Добавлять", ctiField);
    formLayout->addRow("Тех.осмотры | Изменять", ctuField);

    formLayout->addRow("Автомобили | Смотреть", cvsField);
    formLayout->addRow("Автомобили | Удалять", cvdField);
    formLayout->addRow("Автомобили | Добавлять", cviField);
    formLayout->addRow("Автомобили | Изменять", cvuField);

    formLayout->addRow("Сотрудники | Смотреть", cusField);
    formLayout->addRow("Сотрудники | Удалять", cudField);
    formLayout->addRow("Сотрудники | Добавлять", cuiField);
    formLayout->addRow("Сотрудники | Изменять", cuuField);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addLayout(formLayout);
    layout->addWidget(submitButton);
    // setLayout(layout);

    QWidget *container = new QWidget;
    container->setLayout(layout);
    setCentralWidget(container);

    connect(submitButton, &QPushButton::clicked, this, &AddUserWindow::onSubmitButtonClicked);
}

AddUserWindow::~AddUserWindow()
{
    delete ui;
}

void AddUserWindow::onSubmitButtonClicked()
{
    // Создание запроса на добавление новой записи
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

    // Подготовка данных
    QJsonObject postData;

    if (userId > 0) {
        postData["method"] = "editUser";
        postData["id"] = userId;
    } else {
        postData["method"] = "newUser";
    }

    postData["name"] = nameField->text();
    postData["lname"] = lnameField->text();
    postData["login"] = loginField->text();
    postData["pass"] = passField->text();
    postData["can_people_select"] = cpsField->isChecked();
    postData["can_people_delete"] = cpdField->isChecked();
    postData["can_people_insert"] = cpiField->isChecked();
    postData["can_people_update"] = cpuField->isChecked();
    postData["can_techins_select"] = ctsField->isChecked();
    postData["can_techins_delete"] = ctdField->isChecked();
    postData["can_techins_insert"] = ctiField->isChecked();
    postData["can_techins_update"] = ctuField->isChecked();
    postData["can_vehicle_select"] = cvsField->isChecked();
    postData["can_vehicle_delete"] = cvdField->isChecked();
    postData["can_vehicle_insert"] = cviField->isChecked();
    postData["can_vehicle_update"] = cvuField->isChecked();
    postData["can_users_select"] = cusField->isChecked();
    postData["can_users_delete"] = cudField->isChecked();
    postData["can_users_insert"] = cuiField->isChecked();
    postData["can_users_update"] = cuuField->isChecked();

    QNetworkReply *reply = networkManager->post(request, QJsonDocument(postData).toJson());
    connect(reply, &QNetworkReply::finished, this, &AddUserWindow::onNetworkReplyFinished);
}

void AddUserWindow::setWindowTitle(const QString &title){
    QWidget::setWindowTitle(title);
}

void AddUserWindow::setSubmitButtonText(const QString &text){
    submitButton->setText(text);
}

void AddUserWindow::onNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (reply->error() == QNetworkReply::NoError) {
//        QMessageBox::information(this, "Успех", "Запись успешно добавлена.");
        close();
        emit userAdded();
    } else {
        QMessageBox::warning(this, "Ошибка", "Не удалось выполнить запрос: " + reply->errorString());
    }
    reply->deleteLater();
}
