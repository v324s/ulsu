#include "peoplewindow.h"
#include "ui_PeopleWindow.h"
#include "addpeoplewindow.h"

#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QHeaderView>
#include <QModelIndex>
#include <QDebug>

PeopleWindow::PeopleWindow(QWidget *parent, const QString &token, const QJsonObject &userPermissions) :
    QMainWindow(parent),
    ui(new Ui::PeopleWindow),
    authToken(token),
    permissions(userPermissions),
    networkManager(new QNetworkAccessManager(this))
{
    ui->setupUi(this);

    // Создаем таблицу
        tableView = new QTableView(this);
        addButton = new QPushButton("Добавить", this);
        deleteButton = new QPushButton("Удалить", this);
        editButton = new QPushButton("Изменить", this);

        // Установка прав доступа
        addButton->setEnabled(permissions.value("can_people_insert").toInt() == 1);
        deleteButton->setEnabled(permissions.value("can_people_delete").toInt() == 1);
        editButton->setEnabled(permissions.value("can_people_update").toInt() == 1);
        // tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        // tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);


        // Настройка компоновки
        QVBoxLayout *layout = new QVBoxLayout;
        layout->addWidget(tableView);
        layout->addWidget(addButton);
        layout->addWidget(deleteButton);
        layout->addWidget(editButton);

        // Контейнер виджета для компоновки
        QWidget *container = new QWidget;
        container->setLayout(layout);
        setCentralWidget(container);

        connect(addButton, &QPushButton::clicked, this, &PeopleWindow::onAddButtonClicked);
        connect(deleteButton, &QPushButton::clicked, this, &PeopleWindow::onDeleteButtonClicked);
        connect(editButton, &QPushButton::clicked, this, &PeopleWindow::onEditButtonClicked);


        updateTable();  // Загрузка данных пользователей при открытии окна
}

PeopleWindow::~PeopleWindow()
{
    delete ui;
    // delete networkManager;
}



void PeopleWindow::updateTable()
{
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

    QJsonObject postData;
    postData["method"] = "getPeople";

    QNetworkReply *reply = networkManager->post(request, QJsonDocument(postData).toJson());
    connect(reply, &QNetworkReply::finished, this, &PeopleWindow::onNetworkReplyFinished);
}

void PeopleWindow::onNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
        if (reply->error() == QNetworkReply::NoError) {
            // Обработка успешного ответа и заполнение таблицы
            QByteArray response = reply->readAll();
            QJsonDocument jsonResponse = QJsonDocument::fromJson(response);
            QJsonArray jsonArray = jsonResponse.array();

            // Преобразование jsonArray в данные для таблицы
            QStandardItemModel *model = new QStandardItemModel(jsonArray.size(), 9, this);

            // Установка заголовков
            model->setHeaderData(0, Qt::Horizontal, "ID");
            model->setHeaderData(1, Qt::Horizontal, "Имя");
            model->setHeaderData(2, Qt::Horizontal, "Фамилия");
            model->setHeaderData(3, Qt::Horizontal, "Отчество");
            model->setHeaderData(4, Qt::Horizontal, "Номер паспорта");
            model->setHeaderData(5, Qt::Horizontal, "Серия паспорта");
            model->setHeaderData(6, Qt::Horizontal, "Дата рождения");
            model->setHeaderData(7, Qt::Horizontal, "Кем выдан");
            model->setHeaderData(8, Qt::Horizontal, "Дата выдачи");
            model->setHeaderData(9, Qt::Horizontal, "Прописка");

            // Заполнение модели данными
            for (int i = 0; i < jsonArray.size(); ++i) {
                QJsonObject jsonObject = jsonArray[i].toObject();
                model->setItem(i, 0, new QStandardItem(QString::number(jsonObject["id"].toInt())));
                model->setItem(i, 1, new QStandardItem(jsonObject["fname"].toString()));
                model->setItem(i, 2, new QStandardItem(jsonObject["lname"].toString()));
                model->setItem(i, 3, new QStandardItem(jsonObject["llname"].toString()));
                model->setItem(i, 4, new QStandardItem(QString::number(jsonObject["pass_number"].toInt())));
                model->setItem(i, 5, new QStandardItem(QString::number(jsonObject["pass_serial"].toInt())));
                model->setItem(i, 6, new QStandardItem(jsonObject["dob"].toString()));
                model->setItem(i, 7, new QStandardItem(jsonObject["pass_issued"].toString()));
                model->setItem(i, 8, new QStandardItem(jsonObject["pass_issued_date"].toString()));
                model->setItem(i, 9, new QStandardItem(jsonObject["por"].toString()));
            }

            tableView->setModel(model);
        } else {
            // Обработка ошибки
            QMessageBox::warning(this, "Ошибка", "Не удалось получить данные: " + reply->errorString());
        }
    reply->deleteLater();














    // QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    // if (reply->error() != QNetworkReply::NoError) {
    //     QMessageBox::warning(this, "Ошибка", "Не удалось получить данные: " + reply->errorString());
    //     reply->deleteLater();
    //     return;
    // }

    // QJsonDocument jsonResponse = QJsonDocument::fromJson(reply->readAll());
    // QJsonArray jsonArray = jsonResponse.array();

    // QStandardItemModel *model = new QStandardItemModel(jsonArray.size(), 10, this);
    // model->setHeaderData(0, Qt::Horizontal, "ID");
    // model->setHeaderData(1, Qt::Horizontal, "Имя");
    // model->setHeaderData(2, Qt::Horizontal, "Фамилия");
    // model->setHeaderData(3, Qt::Horizontal, "Отчество");
    // model->setHeaderData(4, Qt::Horizontal, "Номер паспорта");
    // model->setHeaderData(5, Qt::Horizontal, "Серия паспорта");
    // model->setHeaderData(6, Qt::Horizontal, "Дата рождения");
    // model->setHeaderData(7, Qt::Horizontal, "Кем выдан");
    // model->setHeaderData(8, Qt::Horizontal, "Дата выдачи");
    // model->setHeaderData(9, Qt::Horizontal, "Прописка");

    // for (int i = 0; i < jsonArray.size(); ++i) {
    //     QJsonObject jsonObject = jsonArray[i].toObject();
    //     model->setItem(i, 0, new QStandardItem(QString::number(jsonObject["id"].toInt())));
    //     model->setItem(i, 1, new QStandardItem(jsonObject["fname"].toString()));
    //     model->setItem(i, 2, new QStandardItem(jsonObject["lname"].toString()));
    //     model->setItem(i, 3, new QStandardItem(jsonObject["llname"].toString()));
    //     //model->setItem(i, 4, new QStandardItem(jsonObject["pass_number"].toString()));
    //     model->setItem(i, 4, new QStandardItem(QString::number(jsonObject["pass_number"].toInt())));
    //     //model->setItem(i, 5, new QStandardItem(jsonObject["pass_serial"].toString()));
    //     model->setItem(i, 5, new QStandardItem(QString::number(jsonObject["pass_serial"].toInt())));
    //     model->setItem(i, 6, new QStandardItem(jsonObject["dob"].toString()));
    //     model->setItem(i, 7, new QStandardItem(jsonObject["pass_issued"].toString()));
    //     model->setItem(i, 8, new QStandardItem(jsonObject["pass_issued_date"].toString()));
    //     model->setItem(i, 9, new QStandardItem(jsonObject["por"].toString()));
    // }


    // tableView->setModel(model);
    // //ui->tableView->setModel(model); // Устанавливаем модель для tableView в peoplewindow.ui
    // reply->deleteLater();
}

void PeopleWindow::onAddButtonClicked()
{
    AddPeopleWindow *addWindow = new AddPeopleWindow(this, authToken);
    connect(addWindow, &AddPeopleWindow::peopleAdded, this, &PeopleWindow::updateTable);
    addWindow->show();
}

void PeopleWindow::onDeleteButtonClicked()
{
    // Логика удаления записи
    QModelIndexList selection = tableView->selectionModel()->selectedRows();
    if (selection.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Выберите строку для удаления.");
        return;
    }

    int row = selection.first().row();
    QStandardItemModel *model = qobject_cast<QStandardItemModel*>(tableView->model());
    int id = model->item(row, 0)->text().toInt();

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Подтверждение удаления",
                                  "Вы уверены, что хотите удалить строку #" + QString::number(id) + "?",
                                  QMessageBox::Yes|QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
        request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

        QJsonObject postData;
        postData["method"] = "deletePeople";
        postData["id"] = id;

        QNetworkReply *networkReply = networkManager->post(request, QJsonDocument(postData).toJson());
        connect(networkReply, &QNetworkReply::finished, this, &PeopleWindow::onDeleteNetworkReplyFinished);
    }








    /*QModelIndexList selectedRows = tableView->selectionModel()->selectedRows();
    if (selectedRows.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, выберите строку для удаления.");
        return;
    }

    int selectedRow = selectedRows.first().row();
    QStandardItemModel *model = qobject_cast<QStandardItemModel*>(tableView->model());
    if (!model) {
        QMessageBox::warning(this, "Ошибка", "Невозможно получить модель данных.");
        return;
    }

    int id = model->item(selectedRow, 0)->text().toInt();

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Удаление", "Вы уверены, что хотите удалить строку #" + QString::number(id) + "?",
                                  QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
        request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

        QJsonObject postData;
        postData["method"] = "deleteTechins";
        postData["id"] = id;

        QNetworkReply *networkReply = networkManager->post(request, QJsonDocument(postData).toJson());
        connect(networkReply, &QNetworkReply::finished, this, &TechinsWindow::onDeleteNetworkReplyFinished);
    }*/
}

void PeopleWindow::onEditButtonClicked()
{
    // Логика редактирования записи
    QModelIndexList selectedRows = tableView->selectionModel()->selectedRows();
    if (selectedRows.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, выберите строку для редактирования.");
        return;
    }

    int selectedRow = selectedRows.first().row();

    QStandardItemModel *model = qobject_cast<QStandardItemModel*>(tableView->model());
    if (!model) {
        QMessageBox::warning(this, "Ошибка", "Невозможно получить модель данных.");
        return;
    }


    int id = model->item(selectedRow, 0)->text().toInt();
    QString name = model->item(selectedRow, 1)->text();
    QString lname = model->item(selectedRow, 2)->text();
    QString llname = model->item(selectedRow, 3)->text();
    int pass_number = model->item(selectedRow, 4)->text().toInt();
    int pass_serial = model->item(selectedRow, 5)->text().toInt();
    QString pass_issued = model->item(selectedRow, 6)->text();
    QString pass_issued_date = model->item(selectedRow, 7)->text();
    QString dob = model->item(selectedRow, 8)->text();
    QString por = model->item(selectedRow, 9)->text();

    AddPeopleWindow *editWindow = new AddPeopleWindow(this, authToken, id, name, lname, llname, pass_number, pass_serial, pass_issued, pass_issued_date, dob, por);
    editWindow->setWindowTitle("Редактировать запись");
    editWindow->setSubmitButtonText("Изменить");
    connect(editWindow, &AddPeopleWindow::peopleAdded, this, &PeopleWindow::updateTable);
    editWindow->show();










    /*QModelIndexList selectedRows = tableView->selectionModel()->selectedRows();
    if (selectedRows.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, выберите строку для редактирования.");
        return;
    }

    int selectedRow = selectedRows.first().row();
    QStandardItemModel *model = qobject_cast<QStandardItemModel*>(tableView->model());
    if (!model) {
        QMessageBox::warning(this, "Ошибка", "Невозможно получить модель данных.");
        return;
    }

    int id = model->item(selectedRow, 0)->text().toInt();
    QString date = model->item(selectedRow, 1)->text();
    QString vehicleId = model->item(selectedRow, 2)->text();
    QString mileage = model->item(selectedRow, 6)->text();
    QString status = model->item(selectedRow, 7)->text();

    AddTechinsWindow *editWindow = new AddTechinsWindow(this, authToken, id, date, vehicleId, mileage, status);
    editWindow->setWindowTitle("Редактировать запись");
    //editWindow->setSubmitButtonText("Изменить");
    connect(editWindow, &AddTechinsWindow::techinsAdded, this, &TechinsWindow::updateTable);
    editWindow->show();*/
}

void PeopleWindow::onDeleteNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (reply->error() == QNetworkReply::NoError) {
        // Успешное удаление
        QMessageBox::information(this, "Успех", "Строка успешно удалена.");
        updateTable();
    } else {
        // Обработка ошибки
        QMessageBox::warning(this, "Ошибка", "Не удалось удалить строку: " + reply->errorString());
    }
    reply->deleteLater();
}
