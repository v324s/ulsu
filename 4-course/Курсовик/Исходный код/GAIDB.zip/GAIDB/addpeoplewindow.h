#ifndef ADDPEOPLEWINDOW_H
#define ADDPEOPLEWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonObject>
#include <QJsonDocument>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QMessageBox>
#include <QString>

namespace Ui {
class AddPeopleWindow;
}

class AddPeopleWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AddPeopleWindow(QWidget *parent = nullptr, const QString &token = "", int id = -1,
                                 const QString &name = "", const QString &lname = "", const QString &llname = "",
                                 int pass_number = 0, int pass_serial = 0,
                                 const QString &pass_issued = "", const QString &pass_issued_date = "", const QString &dob = "", const QString &por = "");
        ~AddPeopleWindow();

    void setWindowTitle(const QString &title);
    void setSubmitButtonText(const QString &text);

private slots:
    void onSubmitButtonClicked();
    void onNetworkReplyFinished();

signals:
    void peopleAdded();

private:
    Ui::AddPeopleWindow *ui;
    QString authToken;
    QNetworkAccessManager *networkManager;

    QLineEdit *idField;
    QLineEdit *nameField;
    QLineEdit *lnameField;
    QLineEdit *llnameField;
    QLineEdit *pnField;
    QLineEdit *psField;
    QLineEdit *piField;
    QLineEdit *pidField;
    QLineEdit *dobField;
    QLineEdit *porField;
    QPushButton *submitButton;
     int peopleId;
};

#endif // ADDPEOPLEWINDOW_H
