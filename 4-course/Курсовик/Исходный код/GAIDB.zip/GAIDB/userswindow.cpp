#include "userswindow.h"
#include "ui_userswindow.h"
#include "adduserwindow.h"

UsersWindow::UsersWindow(QWidget *parent, const QString &token, const QJsonObject &userPermissions) :
    QMainWindow(parent),
    ui(new Ui::UsersWindow),
    authToken(token),
    permissions(userPermissions),
    networkManager(new QNetworkAccessManager(this))
{
    ui->setupUi(this);

    tableView = new QTableView(this);
    addButton = new QPushButton("Добавить", this);
    deleteButton = new QPushButton("Удалить", this);
    editButton = new QPushButton("Изменить", this);

    addButton->setEnabled(permissions.value("can_vehicle_insert").toInt() == 1);
    deleteButton->setEnabled(permissions.value("can_vehicle_delete").toInt() == 1);
    editButton->setEnabled(permissions.value("can_vehicle_update").toInt() == 1);


    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(tableView);
    layout->addWidget(addButton);
    layout->addWidget(deleteButton);
    layout->addWidget(editButton);

    QWidget *container = new QWidget;
    container->setLayout(layout);
    setCentralWidget(container);

    connect(addButton, &QPushButton::clicked, this, &UsersWindow::onAddButtonClicked);
    connect(editButton, &QPushButton::clicked, this, &UsersWindow::onEditButtonClicked);
    connect(deleteButton, &QPushButton::clicked, this, &UsersWindow::onDeleteButtonClicked);

    updateTable();
}

UsersWindow::~UsersWindow() {
    delete ui;
}

void UsersWindow::updateTable()
{
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

    QJsonObject postData;
    postData["method"] = "getUsers";

    QNetworkReply *reply = networkManager->post(request, QJsonDocument(postData).toJson());
    connect(reply, &QNetworkReply::finished, this, &UsersWindow::onNetworkReplyFinished);
}

void UsersWindow::onNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
        if (reply->error() == QNetworkReply::NoError) {
            // Обработка успешного ответа и заполнение таблицы
            QByteArray response = reply->readAll();
            QJsonDocument jsonResponse = QJsonDocument::fromJson(response);
            QJsonArray jsonArray = jsonResponse.array();

            // Установка заголовков
            QStringList headers = {
                "ID",
                "Имя",
                "Фамилия",
                "Логин",
                "Пароль",
                "Люди | Смотреть",
                "Люди | Удалять",
                "Люди | Добавлять",
                "Люди | Изменять",
                "Тех.осмотры | Смотреть",
                "Тех.осмотры | Удалять",
                "Тех.осмотры | Добавлять",
                "Тех.осмотры | Изменять",
                "Автомобили | Смотреть",
                "Автомобили | Удалять",
                "Автомобили | Добавлять",
                "Автомобили | Изменять",
                "Сотрудники | Смотреть",
                "Сотрудники | Удалять",
                "Сотрудники | Добавлять",
                "Сотрудники | Изменять"
            };

            // Преобразование jsonArray в данные для таблицы
            QStandardItemModel *model = new QStandardItemModel(jsonArray.size(), headers.size(), this);


            for (int col = 0; col < headers.size(); ++col) {
                model->setHeaderData(col, Qt::Horizontal, headers[col]);
            }

            // Заполнение модели данными
            for (int i = 0; i < jsonArray.size(); ++i) {
                QJsonObject jsonObject = jsonArray[i].toObject();
                model->setItem(i, 0, new QStandardItem(QString::number(jsonObject["id"].toInt())));
                model->setItem(i, 1, new QStandardItem(jsonObject["fname"].toString()));
                model->setItem(i, 2, new QStandardItem(jsonObject["lname"].toString()));
                model->setItem(i, 3, new QStandardItem(jsonObject["login"].toString()));
                model->setItem(i, 4, new QStandardItem(jsonObject["pass"].toString()));

                QStringList keys = {
                    "can_people_select",
                    "can_people_delete",
                    "can_people_insert",
                    "can_people_update",
                    "can_techins_select",
                    "can_techins_delete",
                    "can_techins_insert",
                    "can_techins_update",
                    "can_vehicle_select",
                    "can_vehicle_delete",
                    "can_vehicle_insert",
                    "can_vehicle_update",
                    "can_users_select",
                    "can_users_delete",
                    "can_users_insert",
                    "can_users_update"
                };

                for (int j = 0; j < keys.size(); ++j) {
//                    bool value = jsonObject[keys[j]].toBool();
                    bool value = jsonObject.contains(keys[j]) ? (jsonObject[keys[j]].toInt() == 1) : false;
                    QString boolString = value ? "Да" : "Нет";
                    model->setItem(i, 5 + j, new QStandardItem(boolString));
                }
            }

            tableView->setModel(model);
        } else {
            // Обработка ошибки
            QMessageBox::warning(this, "Ошибка", "Не удалось получить данные: " + reply->errorString());
        }
    reply->deleteLater();
}

void UsersWindow::onAddButtonClicked()
{
    AddUserWindow *addWindow = new AddUserWindow(this, authToken);
    connect(addWindow, &AddUserWindow::userAdded, this, &UsersWindow::updateTable);
    addWindow->show();
}

void UsersWindow::onDeleteButtonClicked()
{
    // Логика удаления записи
    QModelIndexList selection = tableView->selectionModel()->selectedRows();
    if (selection.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Выберите строку для удаления.");
        return;
    }

    int row = selection.first().row();
    QStandardItemModel *model = qobject_cast<QStandardItemModel*>(tableView->model());
    int id = model->item(row, 0)->text().toInt();

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Подтверждение удаления",
                                  "Вы уверены, что хотите удалить строку #" + QString::number(id) + "?",
                                  QMessageBox::Yes|QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
        request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

        QJsonObject postData;
        postData["method"] = "deleteUser";
        postData["id"] = id;

        QNetworkReply *networkReply = networkManager->post(request, QJsonDocument(postData).toJson());
        connect(networkReply, &QNetworkReply::finished, this, &UsersWindow::onDeleteNetworkReplyFinished);
    }
}

void UsersWindow::onEditButtonClicked()
{
    // Логика редактирования записи
    QModelIndexList selectedRows = tableView->selectionModel()->selectedRows();
    if (selectedRows.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, выберите строку для редактирования.");
        return;
    }

    int selectedRow = selectedRows.first().row();

    QStandardItemModel *model = qobject_cast<QStandardItemModel*>(tableView->model());
    if (!model) {
        QMessageBox::warning(this, "Ошибка", "Невозможно получить модель данных.");
        return;
    }

    int id = model->item(selectedRow, 0)->text().toInt();
    QString name = model->item(selectedRow, 1)->text();
    QString lname = model->item(selectedRow, 2)->text();
    QString login = model->item(selectedRow, 3)->text();
    QString pass = model->item(selectedRow, 4)->text();
    bool cps = model->item(selectedRow, 5)->text() == "Да" ? true : false;
    bool cpd = model->item(selectedRow, 6)->text() == "Да" ? true : false;
    bool cpi = model->item(selectedRow, 7)->text() == "Да" ? true : false;
    bool cpu = model->item(selectedRow, 8)->text() == "Да" ? true : false;
    bool cts = model->item(selectedRow, 9)->text() == "Да" ? true : false;
    bool ctd = model->item(selectedRow, 10)->text() == "Да" ? true : false;
    bool cti = model->item(selectedRow, 11)->text() == "Да" ? true : false;
    bool ctu = model->item(selectedRow, 12)->text() == "Да" ? true : false;
    bool cvs = model->item(selectedRow, 13)->text() == "Да" ? true : false;
    bool cvd = model->item(selectedRow, 14)->text() == "Да" ? true : false;
    bool cvi = model->item(selectedRow, 15)->text() == "Да" ? true : false;
    bool cvu = model->item(selectedRow, 16)->text() == "Да" ? true : false;
    bool cus = model->item(selectedRow, 17)->text() == "Да" ? true : false;
    bool cud = model->item(selectedRow, 18)->text() == "Да" ? true : false;
    bool cui = model->item(selectedRow, 19)->text() == "Да" ? true : false;
    bool cuu = model->item(selectedRow, 20)->text() == "Да" ? true : false;


    AddUserWindow *editWindow = new AddUserWindow(this, authToken, id, name, lname, login, pass, cps, cpd, cpi, cpu, cts, ctd, cti ,ctu, cvs, cvd, cvi, cvu, cus, cud, cui, cuu);
    editWindow->setWindowTitle("Редактировать запись");
    editWindow->setSubmitButtonText("Изменить");
    connect(editWindow, &AddUserWindow::userAdded, this, &UsersWindow::updateTable);
    editWindow->show();

}


void UsersWindow::onDeleteNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (reply->error() == QNetworkReply::NoError) {
        // Успешное удаление
        QMessageBox::information(this, "Успех", "Строка успешно удалена.");
        updateTable();
    } else {
        // Обработка ошибки
        QMessageBox::warning(this, "Ошибка", "Не удалось удалить строку: " + reply->errorString());
    }
    reply->deleteLater();
}
