#ifndef SECONDARYWINDOW_H
#define SECONDARYWINDOW_H

#include <QMainWindow>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QPushButton>
#include <QMessageBox>

#include "vehiclewindow.h"
#include "techinswindow.h"
#include "peoplewindow.h"
#include "userswindow.h"

namespace Ui {
class SecondaryWindow;
}

class SecondaryWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit SecondaryWindow(QWidget *parent = nullptr, const QString &token = "");
    ~SecondaryWindow();

private slots:
    void onNetworkReplyFinished();
    void setButtonAvailability(int value, QPushButton *button);
    void onVehicleButtonClicked();
    void onTechinsButtonClicked();
    void onPeopleButtonClicked();
    void onUsersButtonClicked();


private:
    Ui::SecondaryWindow *ui;
    QString authToken;
    QNetworkAccessManager *networkManager;
    QJsonArray jsonArray;
    QJsonObject userPermissions;
};

#endif // SECONDARYWINDOW_H
