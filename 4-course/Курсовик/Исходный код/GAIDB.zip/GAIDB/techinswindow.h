#ifndef TECHINSWINDOW_H
#define TECHINSWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QTableView>
#include <QPushButton>
#include <QVBoxLayout>
#include <QJsonObject>

namespace Ui {
class TechinsWindow;
}

class TechinsWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit TechinsWindow(QWidget *parent = nullptr, const QString &token = "", const QJsonObject &userPermissions = QJsonObject());
    ~TechinsWindow();

private slots:
    void onAddButtonClicked();
    void onDeleteButtonClicked();
    void onEditButtonClicked();
    void updateTable();
    void onNetworkReplyFinished();
    void onDeleteNetworkReplyFinished();

private:
    Ui::TechinsWindow *ui;
    QString authToken;
    QJsonObject permissions;
    QNetworkAccessManager *networkManager;
    QTableView *tableView;
    QPushButton *addButton;
    QPushButton *deleteButton;
    QPushButton *editButton;
};

#endif // TECHINSWINDOW_H
