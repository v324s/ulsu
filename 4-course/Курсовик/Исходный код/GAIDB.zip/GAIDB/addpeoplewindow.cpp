#include "addpeoplewindow.h"
#include "ui_AddPeopleWindow.h"

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMessageBox>

AddPeopleWindow::AddPeopleWindow(QWidget *parent, const QString &token, int id, const QString &name, const QString &lname,const QString &llname, int pass_number, int pass_serial,const QString &pass_issued, const QString &pass_issued_date, const QString &dob, const QString &por) :
    QMainWindow(parent),
    ui(new Ui::AddPeopleWindow),
    authToken(token),
    networkManager(new QNetworkAccessManager(this)),
    peopleId(id)
{
    ui->setupUi(this);

    nameField = new QLineEdit(this);
    lnameField = new QLineEdit(this);
    llnameField = new QLineEdit(this);
    pnField = new QLineEdit(this);
    psField = new QLineEdit(this);
    piField = new QLineEdit(this);
    pidField = new QLineEdit(this);
    dobField = new QLineEdit(this);
    porField = new QLineEdit(this);
    submitButton = new QPushButton("Добавить", this);

    if (peopleId != -1) {
        idField = new QLineEdit(this);
        idField->setText(QString(id));
        idField->setEnabled(false);
        // Устанавливаем значения в поля формы
        nameField->setText(name);
        lnameField->setText(lname);
        llnameField->setText(llname);
        pnField->setText(QString::number(pass_number));
        psField->setText(QString::number(pass_serial));
        piField->setText(pass_issued);
        pidField->setText(pass_issued_date);
        dobField->setText(dob);
        porField->setText(por);

        submitButton->setText("Изменить");
    }

    QFormLayout *formLayout = new QFormLayout;
//    formLayout->addRow("ID", idField);
    formLayout->addRow("Имя", nameField);
    formLayout->addRow("Фамилия", lnameField);
    formLayout->addRow("Отчество", llnameField);
    formLayout->addRow("Номер паспорта", pnField);
    formLayout->addRow("Серия паспорта", psField);
    formLayout->addRow("Кем выдан", piField);
    formLayout->addRow("Дата выдачи", pidField);
    formLayout->addRow("Дата рождения", dobField);
    formLayout->addRow("Прописка", porField);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addLayout(formLayout);
    layout->addWidget(submitButton);
    // setLayout(layout);

    QWidget *container = new QWidget;
    container->setLayout(layout);
    setCentralWidget(container);

    connect(submitButton, &QPushButton::clicked, this, &AddPeopleWindow::onSubmitButtonClicked);
}

AddPeopleWindow::~AddPeopleWindow()
{
    delete ui;
//    delete networkManager;
}

void AddPeopleWindow::onSubmitButtonClicked()
{
    // Создание запроса на добавление новой записи
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

    // Подготовка данных
    QJsonObject postData;

    //QMessageBox::warning(this, "Ошибка", "vehicleId: " + QString::number(vehicleId));

    if (peopleId > 0) {
        postData["method"] = "editPeople";
        postData["id"] = peopleId;
    } else {
        postData["method"] = "newPeople";
    }

//    postData["id"] = idField->text().toInt();
    postData["name"] = nameField->text();
    postData["lname"] = lnameField->text();
    postData["llname"] = llnameField->text();
    postData["pn"] = pnField->text().toInt();
    postData["ps"] = psField->text().toInt();
    postData["pi"] = piField->text();
    postData["pid"] = pidField->text();
    postData["dob"] = dobField->text();
    postData["por"] = porField->text();

    QNetworkReply *reply = networkManager->post(request, QJsonDocument(postData).toJson());
    connect(reply, &QNetworkReply::finished, this, &AddPeopleWindow::onNetworkReplyFinished);
}

void AddPeopleWindow::setWindowTitle(const QString &title){
    QWidget::setWindowTitle(title);
}

void AddPeopleWindow::setSubmitButtonText(const QString &text){
    submitButton->setText(text);
}

void AddPeopleWindow::onNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (reply->error() == QNetworkReply::NoError) {
//        QMessageBox::information(this, "Успех", "Запись успешно добавлена.");
        close();
        emit peopleAdded();
    } else {
        QMessageBox::warning(this, "Ошибка", "Не удалось выполнить запрос: " + reply->errorString());
    }
    reply->deleteLater();














//    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
//    if (reply->error() == QNetworkReply::NoError) {
//        // Обработка успешного ответа
////        QMessageBox::information(this, "Успех", "Запись успешно добавлена.");
//        close(); // Закрытие формы добавления
//        emit peopleAdded(); // Сигнал для обновления таблицы
//    } else {
//        // Обработка ошибки
//        QMessageBox::warning(this, "Ошибка", "Не удалось выполнить запрос: " + reply->errorString());
//    }
//    reply->deleteLater();

    // QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    // if (reply->error() == QNetworkReply::NoError) {
    //     QMessageBox::information(this, "Успех", peopleId == -1 ? "Запись успешно добавлена." : "Запись успешно изменена.");
    //     emit peopleAdded();
    //     close();
    // } else {
    //     QMessageBox::warning(this, "Ошибка", "Не удалось выполнить запрос: " + reply->errorString());
    // }
    // reply->deleteLater();
}
