#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , networkManager(new QNetworkAccessManager(this))
    , secondaryWindow(nullptr)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    // Создаем запрос
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded");

    // Создаем параметры для POST-запроса
    QUrlQuery postData;
    postData.addQueryItem("method", "auth");
    postData.addQueryItem("login", ui->lineEdit->text());
    postData.addQueryItem("pass", ui->lineEdit_2->text());

    // Отправляем POST-запрос
    QNetworkReply *reply = networkManager->post(request, postData.toString(QUrl::FullyEncoded).toUtf8());

    // Обработка ответа
    connect(reply, &QNetworkReply::finished, [=]() {
        if (reply->error() == QNetworkReply::NoError) {
            // Обработка успешного ответа
            QByteArray response = reply->readAll();
            QString responseString(response);
            if (responseString == "1001"){
                QMessageBox msgBox;
                msgBox.setText("Неверный логин/пароль");
                msgBox.exec();
            }else{
                authToken = responseString;
                if (!secondaryWindow){
                    secondaryWindow = new SecondaryWindow(this, authToken);
                    this->hide();
                    secondaryWindow->show();
                }
            }

        } else {
            // Обработка ошибки
            QMessageBox msgBox;
            msgBox.setText("Ошибка:" + reply->errorString());
            msgBox.exec();
        }
        reply->deleteLater();
    });
}
