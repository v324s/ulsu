#include "addvehiclewindow.h"
#include "ui_addvehiclewindow.h"

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMessageBox>

AddVehicleWindow::AddVehicleWindow(QWidget *parent, const QString &token, int id, const QString &make, const QString &model, const QString &type, const QString &stateNumber, const QString &engineNumber, const QString &bodyNumber, const QString &owner, int horsepower) :
//AddVehicleWindow::AddVehicleWindow(QWidget *parent, const QString &token) :
    QMainWindow(parent),
    ui(new Ui::AddVehicleWindow),
    authToken(token),
    networkManager(new QNetworkAccessManager(this)),
    vehicleId(id)
{
    ui->setupUi(this);

    // Инициализация полей ввода
//    idField = new QLineEdit(this);
    makeField = new QLineEdit(this);
    modelField = new QLineEdit(this);
    typeField = new QLineEdit(this);
    stateNumberField = new QLineEdit(this);
    numberEngineField = new QLineEdit(this);
    numberBodyField = new QLineEdit(this);
    ownerField = new QLineEdit(this);
    horsepowerField = new QLineEdit(this);
    submitButton = new QPushButton("Добавить", this);

    //QMessageBox::warning(this, "Ошибка", "vehicleId: " + QString::number(vehicleId));

    if (vehicleId != -1) {

            idField = new QLineEdit(this);
            idField->setText(QString(id));
            idField->setEnabled(false);
            // Устанавливаем значения в поля формы
            makeField->setText(make);
            modelField->setText(model);
            typeField->setText(type);
            stateNumberField->setText(stateNumber);
            numberEngineField->setText(engineNumber);
            numberBodyField->setText(bodyNumber);
            ownerField->setText(owner);
            horsepowerField->setText(QString::number(horsepower));

            submitButton->setText("Изменить");
        }

    // Установка формы ввода данных
    QFormLayout *formLayout = new QFormLayout;
//    formLayout->addRow("ID", idField);
    formLayout->addRow("Марка", makeField);
    formLayout->addRow("Модель", modelField);
    formLayout->addRow("Тип кузова", typeField);
    formLayout->addRow("Гос. Номер", stateNumberField);
    formLayout->addRow("Номер двигателя", numberEngineField);
    formLayout->addRow("Номер кузова", numberBodyField);
    formLayout->addRow("Владелец", ownerField);
    formLayout->addRow("Мощность двигателя (л.с.)", horsepowerField);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addLayout(formLayout);
    layout->addWidget(submitButton);

    QWidget *container = new QWidget;
    container->setLayout(layout);
    setCentralWidget(container);

    connect(submitButton, &QPushButton::clicked, this, &AddVehicleWindow::onSubmitButtonClicked);
}

AddVehicleWindow::~AddVehicleWindow()
{
    delete ui;
}

void AddVehicleWindow::onSubmitButtonClicked()
{
    // Создание запроса на добавление новой записи
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

    // Подготовка данных
    QJsonObject postData;

    //QMessageBox::warning(this, "Ошибка", "vehicleId: " + QString::number(vehicleId));

    if (vehicleId > 0) {
        postData["method"] = "editVehicle";
        postData["id"] = vehicleId;
    } else {
        postData["method"] = "newVehicle";
    }

//    postData["id"] = idField->text().toInt();
    postData["make"] = makeField->text();
    postData["model"] = modelField->text();
    postData["type"] = typeField->text();
    postData["state_number"] = stateNumberField->text();
    postData["number_engine"] = numberEngineField->text();
    postData["number_body"] = numberBodyField->text();
    postData["owner"] = ownerField->text();
    postData["horsepower"] = horsepowerField->text().toInt();

    QNetworkReply *reply = networkManager->post(request, QJsonDocument(postData).toJson());
    connect(reply, &QNetworkReply::finished, this, &AddVehicleWindow::onNetworkReplyFinished);
}

void AddVehicleWindow::setWindowTitle(const QString &title){
    QWidget::setWindowTitle(title);
}

void AddVehicleWindow::setSubmitButtonText(const QString &text){
    submitButton->setText(text);
}

void AddVehicleWindow::onNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (reply->error() == QNetworkReply::NoError) {
        // Обработка успешного ответа
//        QMessageBox::information(this, "Успех", "Запись успешно добавлена.");
        close(); // Закрытие формы добавления
        emit vehicleAdded(); // Сигнал для обновления таблицы
    } else {
        // Обработка ошибки
        QMessageBox::warning(this, "Ошибка", "Не удалось выполнить запрос: " + reply->errorString());
    }
    reply->deleteLater();
}
