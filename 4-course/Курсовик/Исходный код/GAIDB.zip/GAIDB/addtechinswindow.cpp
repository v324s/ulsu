#include "addtechinswindow.h"
#include "ui_addtechinswindow.h"

#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QLineEdit>
#include <QPushButton>
#include <QFormLayout>
#include <QVBoxLayout>

AddTechinsWindow::AddTechinsWindow(QWidget *parent, const QString &token, int id, const QString &date, const QString &vehicleId, const QString &mileage, const QString &status) :
    QMainWindow(parent),
    ui(new Ui::AddTechinsWindow),
    authToken(token),
    techinsId(id),
    networkManager(new QNetworkAccessManager(this))
{
    ui->setupUi(this);

    // Инициализация полей ввода
    dateEdit = new QLineEdit(this);
    vehicleIdEdit = new QLineEdit(this);
    mileageEdit = new QLineEdit(this);
    statusEdit = new QLineEdit(this);
    submitButton = new QPushButton("Добавить", this);

    if (id != -1) {
        // ui->dateEdit->setText(date);
        // ui->makeEdit->setText(make);
        // ui->modelEdit->setText(vehicleModel);
        // ui->numberEdit->setText(number);
        // ui->statusEdit->setText(status);
        dateEdit->setText(date);
        vehicleIdEdit->setText(vehicleId);
        mileageEdit->setText(mileage);
        statusEdit->setText(status);
        submitButton->setText("Изменить");
    }

     // Установка формы ввода данных
    QFormLayout *formLayout = new QFormLayout;
    formLayout->addRow("Дата", dateEdit);
    formLayout->addRow("ID автомобиля", vehicleIdEdit);
    formLayout->addRow("Пробег", mileageEdit);
    formLayout->addRow("Статус", statusEdit);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addLayout(formLayout);
    layout->addWidget(submitButton);

    // QWidget *container = new QWidget;
    // container->setLayout(layout);
    // setCentralWidget(container);

    QWidget *container = new QWidget;
        container->setLayout(layout);
        setCentralWidget(container);

    //setLayout(layout);

     // Подключение кнопки отправки данных
    connect(submitButton, &QPushButton::clicked, this, &AddTechinsWindow::onSubmitButtonClicked);

    // connect(ui->submitButton, &QPushButton::clicked, this, &AddTechinsWindow::onSubmitButtonClicked);
}

AddTechinsWindow::~AddTechinsWindow()
{
    delete ui;
}

// void AddTechinsWindow::setSubmitButtonText(const QString &text)
// {
//     ui->submitButton->setText(text);
// }

void AddTechinsWindow::onSubmitButtonClicked()
{
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

    QJsonObject postData;
    if (techinsId == -1) {
        postData["method"] = "newTechins";
    } else {
        postData["method"] = "editTechins";
        postData["id"] = techinsId;
    }
    // postData["date"] = ui->dateEdit->text();
    // postData["vehicle_make"] = ui->makeEdit->text();
    // postData["vehicle_model"] = ui->modelEdit->text();
    // postData["vehicle_number"] = ui->numberEdit->text();
    // postData["status"] = ui->statusEdit->text();
    postData["date"] = dateEdit->text();
    postData["vehicle_id"] = vehicleIdEdit->text().toInt();
    postData["mileage"] = mileageEdit->text().toInt();
    postData["status"] = statusEdit->text();

    QNetworkReply *reply = networkManager->post(request, QJsonDocument(postData).toJson());
    connect(reply, &QNetworkReply::finished, this, &AddTechinsWindow::onNetworkReplyFinished);
}

void AddTechinsWindow::onNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (reply->error() == QNetworkReply::NoError) {
        QMessageBox::information(this, "Успех", techinsId == -1 ? "Запись успешно добавлена." : "Запись успешно изменена.");
        emit techinsAdded();
        close();
    } else {
        QMessageBox::warning(this, "Ошибка", "Не удалось выполнить запрос: " + reply->errorString());
    }
    reply->deleteLater();
}
