<?php

define('DB_SERVER','');
define('DB_NAME','');
define('DB_LOGIN','');
define('DB_PASS','');

define('DB_TABLE_USERS','users');
define('DB_TABLE_VEHICLES','vehicle');
define('DB_TABLE_PEOPLES','people');
define('DB_TABLE_TECHINS','techins');

define('TOKEN_SECRETKEY','TopSecret');
define('TOKEN_NAMEORG','gibdd');

?>