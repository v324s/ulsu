<?php
// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);

require_once('settings.php');

require_once("vendor/autoload.php"); // Подключаем автозагрузчик Composer




use Firebase\JWT\JWT;

use Firebase\JWT\Key;





$headers = getallheaders();



if (!isset($headers['Authorization']) && $_POST['method'] != 'auth'){

    connectionClose(401);

    exit();

}



function generateAuthToken($userId, $expirationTime = 3600) {

    $payload = [

      "sub" => $userId, 

      "iat" => time(), // Время создания токена

      "exp" => time() + $expirationTime // Время истечения токена (через сколько секунд токен будет недействителен)

    ];



    $jwt = JWT::encode($payload, TOKEN_SECRETKEY, 'HS256'); // Подписываем токен с использованием секретного ключа

    return $jwt;

}

function decodeAuthToken($token) {

    $decoded = JWT::decode($token, new Key(TOKEN_SECRETKEY, 'HS256'));

    return $decoded;

}



if (isset($headers['Authorization'])){

    $data = file_get_contents("php://input");

    if ($headers['Content-Type']== 'application/json') {

        $data = json_decode($data, true);



        switch ($data['method']) {

            case 'getMe':

                $token = explode(" ",$headers['Authorization']);

                $data = decodeAuthToken($token[1]);

                $pdo = connect();

                $sql = "SELECT * FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                $sth = $pdo->prepare($sql);

                try {

                    $res = $sth->execute(

                        array(

                            'id' => $data->sub, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row == false) {

                        echo '2001'; // Пользователь не найден

                    }else{

                        $filteredResult = removeNumericKeys($row);

                        echo json_encode($filteredResult);

                    }

                }catch (\Throwable $th) {

                    echo $th->getMessage();

                }

            break;



            case 'getVehicles':

                $token = explode(" ",$headers['Authorization']);

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'select', DB_TABLE_VEHICLES)) {

                    $pdo = connect();

                    $sql = "SELECT * FROM " . DB_TABLE_VEHICLES;

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute();

                        $row = $sth->fetchAll();

                        if ($row == false) {

                            echo '3002'; // Ошибка запроса

                        }else{

                            $filteredResult = removeNumericKeys($row);

                            echo json_encode($filteredResult);

                        }

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'newVehicle':

                $token = explode(" ",$headers['Authorization']);

                $newVehicle = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'insert', DB_TABLE_VEHICLES)) {

                    $pdo = connect();

                    $sql = "INSERT INTO " . DB_TABLE_VEHICLES ." (`make`,`model`,`type`,`state_number`,`number_engine`,`number_body`,`owner`,`horsepower`) VALUES (:make, :model, :type, :state_number, :number_engine, :number_body, :owner, :horsepower)";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute([

                            'make' => $newVehicle['make'],

                            'model' => $newVehicle['model'],

                            'type' => $newVehicle['type'],

                            'state_number' => $newVehicle['state_number'],

                            'number_engine' => $newVehicle['number_engine'],

                            'number_body' => $newVehicle['number_body'],

                            'owner' => $newVehicle['owner'],

                            'horsepower' => $newVehicle['horsepower']

                        ]);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'deleteVehicle':

                $token = explode(" ",$headers['Authorization']);

                $vehicle = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'delete', DB_TABLE_VEHICLES)) {

                    $pdo = connect();

                    $sql = "DELETE FROM " . DB_TABLE_VEHICLES ." WHERE `id`=:id";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute([

                            'id' => $vehicle['id']

                        ]);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'editVehicle':

                $token = explode(" ",$headers['Authorization']);

                $vehicle = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'update', DB_TABLE_VEHICLES)) {

                    $pdo = connect();

                    $sql = "UPDATE " . DB_TABLE_VEHICLES ." SET `make`=:make,`model`=:model,`type`=:type,`state_number`=:state_number,`number_engine`=:number_engine,`number_body`=:number_body,`owner`=:owner,`horsepower`=:horsepower WHERE `id`=:id";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute([

                            'id' => $vehicle['id'],

                            'make' => $vehicle['make'],

                            'model' => $vehicle['model'],

                            'type' => $vehicle['type'],

                            'state_number' => $vehicle['state_number'],

                            'number_engine' => $vehicle['number_engine'],

                            'number_body' => $vehicle['number_body'],

                            'owner' => $vehicle['owner'],

                            'horsepower' => $vehicle['horsepower']

                        ]);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'getTechins':

                $token = explode(" ",$headers['Authorization']);

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'select', DB_TABLE_TECHINS)) {

                    $pdo = connect();

                    // $sql = "SELECT * FROM " . DB_TABLE_TECHINS;

                    $sql = "SELECT

                                techins.id,

                                techins.date,

                                techins.vehicle_id,

                                vehicle.make AS vehicle_make,

                                vehicle.model AS vehicle_model,

                                vehicle.number_body AS vehicle_number_body,

                                techins.mileage,

                                techins.status

                            FROM

                                techins

                            JOIN

                                vehicle ON techins.vehicle_id = vehicle.id;

                            ";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute();

                        $row = $sth->fetchAll();

                        if ($row == false) {

                            echo '5002'; // Ошибка запроса

                        }else{

                            $filteredResult = removeNumericKeys($row);

                            echo json_encode($filteredResult);

                        }

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                    }

                }else{

                    // echo "5003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'newTechins':

                $token = explode(" ",$headers['Authorization']);

                $object = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'insert', DB_TABLE_TECHINS)) {

                    $pdo = connect();

                    $sql = "INSERT INTO " . DB_TABLE_TECHINS ." (`date`, `vehicle_id`, `mileage`, `status`)VALUES (:date, :vehicle_id, :mileage, :status)";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute([

                            'mileage' => $object['mileage'],

                            'date' => $object['date'],

                            'status' => $object['status'],

                            'vehicle_id' => $object['vehicle_id']

                        ]);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'editTechins':

                $token = explode(" ",$headers['Authorization']);

                $object = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'update', DB_TABLE_TECHINS)) {

                    $pdo = connect();

                    $sql = "UPDATE " . DB_TABLE_TECHINS ." SET `mileage`=:mileage,`date`=:date,`status`=:status,`vehicle_id`=:vehicle_id WHERE `id`=:id";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute([

                            'id' => $object['id'],

                            'mileage' => $object['mileage'],

                            'date' => $object['date'],

                            'status' => $object['status'],

                            'vehicle_id' => $object['vehicle_id']

                        ]);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'deleteTechins':

                $token = explode(" ",$headers['Authorization']);

                $object = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'delete', DB_TABLE_TECHINS)) {

                    $pdo = connect();

                    $sql = "DELETE FROM " . DB_TABLE_TECHINS ." WHERE `id`=:id";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute([

                            'id' => $object['id']

                        ]);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'getPeople':

                $token = explode(" ",$headers['Authorization']);

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'select', DB_TABLE_PEOPLES)) {

                    $pdo = connect();

                    $sql = "SELECT * FROM " . DB_TABLE_PEOPLES;

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute();

                        $row = $sth->fetchAll();

                        if ($row == false) {

                            echo '6002'; // Ошибка запроса

                        }else{

                            $filteredResult = removeNumericKeys($row);

                            echo json_encode($filteredResult);

                        }

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                    }

                }else{

                    // echo "6003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'newPeople':

                $token = explode(" ",$headers['Authorization']);

                $object = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'insert', DB_TABLE_PEOPLES)) {

                    $pdo = connect();

                    $sql = "INSERT INTO " . DB_TABLE_PEOPLES ." (`fname`,`lname`,`llname`,`pass_number`,`pass_serial`,`dob`,`pass_issued`,`pass_issued_date`,`por`) VALUES (:fname, :lname, :llname, :pass_number, :pass_serial, :dob, :pass_issued, :pass_issued_date, :por)";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute([

                            'fname' => $object['name'],

                            'lname' => $object['lname'],

                            'llname' => $object['llname'],

                            'pass_number' => $object['pn'],

                            'pass_serial' => $object['ps'],

                            'dob' => $object['dob'],

                            'pass_issued' => $object['pi'],

                            'pass_issued_date' => $object['pid'],

                            'por' => $object['por']

                        ]);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'editPeople':

                $token = explode(" ",$headers['Authorization']);

                $object = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'update', DB_TABLE_PEOPLES)) {

                    $pdo = connect();

                    $sql = "UPDATE " . DB_TABLE_PEOPLES ." SET `fname`=:fname,`lname`=:lname,`llname`=:llname,`pass_number`=:pass_number,`pass_serial`=:pass_serial,`dob`=:dob,`pass_issued`=:pass_issued,`pass_issued_date`=:pass_issued_date,`por`=:por WHERE `id`=:id";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute([

                            'id' => $object['id'],

                            'fname' => $object['name'],

                            'lname' => $object['lname'],

                            'llname' => $object['llname'],

                            'pass_number' => $object['pn'],

                            'pass_serial' => $object['ps'],

                            'dob' => $object['dob'],

                            'pass_issued' => $object['pi'],

                            'pass_issued_date' => $object['pid'],

                            'por' => $object['por']

                        ]);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'deletePeople':

                $token = explode(" ",$headers['Authorization']);

                $object = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'delete', DB_TABLE_PEOPLES)) {

                    $pdo = connect();

                    $sql = "DELETE FROM " . DB_TABLE_PEOPLES ." WHERE `id`=:id";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute([

                            'id' => $object['id']

                        ]);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'getUsers':

                $token = explode(" ",$headers['Authorization']);

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'select', DB_TABLE_USERS)) {

                    $pdo = connect();

                    $sql = "SELECT * FROM " . DB_TABLE_USERS;

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute();

                        $row = $sth->fetchAll();

                        if ($row == false) {

                            echo '6002'; // Ошибка запроса

                        }else{

                            $filteredResult = removeNumericKeys($row);

                            echo json_encode($filteredResult);

                        }

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                    }

                }else{

                    // echo "6003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'deleteUser':

                $token = explode(" ",$headers['Authorization']);

                $object = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'delete', DB_TABLE_USERS)) {

                    $pdo = connect();

                    $sql = "DELETE FROM " . DB_TABLE_USERS ." WHERE `id`=:id";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute([

                            'id' => $object['id']

                        ]);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'newUser':

                $token = explode(" ",$headers['Authorization']);

                $object = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'insert', DB_TABLE_USERS)) {

                    $pdo = connect();

                    $sql = "INSERT INTO " . DB_TABLE_USERS ." (`fname`, `lname`, `login`, `pass`, `can_people_select`, `can_people_delete`, `can_people_insert`, `can_people_update`, `can_techins_select`, `can_techins_delete`, `can_techins_insert`, `can_techins_update`, `can_vehicle_select`, `can_vehicle_delete`, `can_vehicle_insert`, `can_vehicle_update`, `can_users_select`, `can_users_delete`, `can_users_insert`, `can_users_update`) VALUES (:fname, :lname, :login, :pass, :can_people_select, :can_people_delete, :can_people_insert, :can_people_update, :can_techins_select, :can_techins_delete, :can_techins_insert, :can_techins_update, :can_vehicle_select, :can_vehicle_delete, :can_vehicle_insert, :can_vehicle_update, :can_users_select, :can_users_delete, :can_users_insert, :can_users_update)";

                    $sth = $pdo->prepare($sql);

                    try {

                        $res = $sth->execute([

                            'fname' => $object['name'],

                            'lname' => $object['lname'],

                            'login' => $object['login'],

                            'pass' => md5($object['pass']),

                            'can_people_select' => $object['can_people_select'],

                            'can_people_delete' => $object['can_people_delete'],

                            'can_people_insert' => $object['can_people_insert'],

                            'can_people_update' => $object['can_people_update'],

                            'can_techins_select' => $object['can_techins_select'],

                            'can_techins_delete' => $object['can_techins_delete'],

                            'can_techins_insert' => $object['can_techins_insert'],

                            'can_techins_update' => $object['can_techins_update'],

                            'can_vehicle_select' => $object['can_vehicle_select'],

                            'can_vehicle_delete' => $object['can_vehicle_delete'],

                            'can_vehicle_insert' => $object['can_vehicle_insert'],

                            'can_vehicle_update' => $object['can_vehicle_update'],

                            'can_users_select' => $object['can_users_select'],

                            'can_users_delete' => $object['can_users_delete'],

                            'can_users_insert' => $object['can_users_insert'],

                            'can_users_update' => $object['can_users_update']

                        ]);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;



            case 'editUser':

                $token = explode(" ",$headers['Authorization']);

                $object = $data;

                $data = decodeAuthToken($token[1]);

                if (accessAllowed($data->sub, 'update', DB_TABLE_USERS)) {

                    $pdo = connect();

                    var_dump(mb_strlen($object['pass']));

                    if (mb_strlen($object['pass']) > 0){

                        $sql = "UPDATE " . DB_TABLE_USERS ." SET `fname`=:fname,`lname`=:lname,`login`=:login,`pass`=:pass,`can_people_select`=:can_people_select,`can_people_delete`=:can_people_delete,`can_people_insert`=:can_people_insert,`can_people_update`=:can_people_update,`can_techins_select`=:can_techins_select,`can_techins_delete`=:can_techins_delete,`can_techins_insert`=:can_techins_insert,`can_techins_update`=:can_techins_update,`can_vehicle_select`=:can_vehicle_select,`can_vehicle_delete`=:can_vehicle_delete,`can_vehicle_insert`=:can_vehicle_insert,`can_vehicle_update`=:can_vehicle_update,`can_users_select`=:can_users_select,`can_users_delete`=:can_users_delete,`can_users_insert`=:can_users_insert,`can_users_update`=:can_users_update WHERE `id`=:id";

                    }else{

                        $sql = "UPDATE " . DB_TABLE_USERS ." SET `fname`=:fname,`lname`=:lname,`login`=:login,`can_people_select`=:can_people_select,`can_people_delete`=:can_people_delete,`can_people_insert`=:can_people_insert,`can_people_update`=:can_people_update,`can_techins_select`=:can_techins_select,`can_techins_delete`=:can_techins_delete,`can_techins_insert`=:can_techins_insert,`can_techins_update`=:can_techins_update,`can_vehicle_select`=:can_vehicle_select,`can_vehicle_delete`=:can_vehicle_delete,`can_vehicle_insert`=:can_vehicle_insert,`can_vehicle_update`=:can_vehicle_update,`can_users_select`=:can_users_select,`can_users_delete`=:can_users_delete,`can_users_insert`=:can_users_insert,`can_users_update`=:can_users_update WHERE `id`=:id";

                    }

                    

                    $sth = $pdo->prepare($sql);

                    try {
                        $arr = [

                            'id' => $object['id'],

                            'fname' => $object['name'],

                            'lname' => $object['lname'],

                            'login' => $object['login'],

                            'pass' => mb_strlen($object['pass']) > 0 ? md5($object['pass']) : null,

                            'can_people_select' => $object['can_people_select'],

                            'can_people_delete' => $object['can_people_delete'],

                            'can_people_insert' => $object['can_people_insert'],

                            'can_people_update' => $object['can_people_update'],

                            'can_techins_select' => $object['can_techins_select'],

                            'can_techins_delete' => $object['can_techins_delete'],

                            'can_techins_insert' => $object['can_techins_insert'],

                            'can_techins_update' => $object['can_techins_update'],

                            'can_vehicle_select' => $object['can_vehicle_select'],

                            'can_vehicle_delete' => $object['can_vehicle_delete'],

                            'can_vehicle_insert' => $object['can_vehicle_insert'],

                            'can_vehicle_update' => $object['can_vehicle_update'],

                            'can_users_select' => $object['can_users_select'],

                            'can_users_delete' => $object['can_users_delete'],

                            'can_users_insert' => $object['can_users_insert'],

                            'can_users_update' => $object['can_users_update']

                        ];

                        if (isset($arr['pass']) && $arr['pass'] == null) {
                            unset($arr['pass']);
                        }

                        $res = $sth->execute($arr);

                        $row = $sth->fetch();

                        echo $row;

                    }catch (\Throwable $th) {

                        echo $th->getMessage();

                        connectionClose(500);

                    }

                }else{

                    // echo "3003"; // Недостаточно прав

                    connectionClose(403);

                }

            break;

            

            default:

                connectionClose(404);

                break;

        }

    }

}



function connectionClose(int $code) {

    http_response_code($code);

    header("Connection: close");

    ob_start();

    $size = ob_get_length();

    header("Content-Length: $size");

    ob_end_flush();

    flush();

}





function removeNumericKeys($data) {

    $result = array();

    foreach ($data as $key => $value) {

        if (is_array($value)) {

            $result[$key] = removeNumericKeys($value);

        } else {

            if (is_string($key)) {

                $result[$key] = $value;

            }

        }

    }

    return $result;

}



// Проверка разрешений

function accessAllowed($userId, $method, $table) : bool {

    switch ($method) {

        case 'select':

            switch ($table) {

                case DB_TABLE_VEHICLES:

                    $pdo = connect();

                    $sql = "SELECT `can_vehicle_select` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_PEOPLES:

                    $pdo = connect();

                    $sql = "SELECT `can_people_select` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_USERS:

                    $pdo = connect();

                    $sql = "SELECT `can_users_select` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_TECHINS:

                    $pdo = connect();

                    $sql = "SELECT `can_techins_select` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;

            }

        break;



        case 'update':

            switch ($table) {

                case DB_TABLE_VEHICLES:

                    $pdo = connect();

                    $sql = "SELECT `can_vehicle_update` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_PEOPLES:

                    $pdo = connect();

                    $sql = "SELECT `can_people_update` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_USERS:

                    $pdo = connect();

                    $sql = "SELECT `can_users_update` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_TECHINS:

                    $pdo = connect();

                    $sql = "SELECT `can_techins_update` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;

            }

        break;



        case 'delete':

            

            switch ($table) {

                case DB_TABLE_VEHICLES:

                    $pdo = connect();

                    $sql = "SELECT `can_vehicle_delete` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_PEOPLES:

                    $pdo = connect();

                    $sql = "SELECT `can_people_delete` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_USERS:

                    $pdo = connect();

                    $sql = "SELECT `can_users_delete` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_TECHINS:

                    $pdo = connect();

                    $sql = "SELECT `can_techins_delete` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;

            }

        break;



        case 'insert':

            switch ($table) {

                case DB_TABLE_VEHICLES:

                    $pdo = connect();

                    $sql = "SELECT `can_vehicle_insert` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_PEOPLES:

                    $pdo = connect();

                    $sql = "SELECT `can_people_insert` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_USERS:

                    $pdo = connect();

                    $sql = "SELECT `can_users_insert` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;



                case DB_TABLE_TECHINS:

                    $pdo = connect();

                    $sql = "SELECT `can_techins_insert` FROM " . DB_TABLE_USERS . " WHERE `id` = :id";

                    $sth = $pdo->prepare($sql);

                    $res = $sth->execute(

                        array(

                            'id' => $userId, 

                        )

                    );

                    $row = $sth->fetch();

                    if ($row) {

                        return $row[0];

                    }

                break;

            }

        break;

    }

}




// !isset($headers['Authorization']) && isset($_POST['method']) && $_POST['method'] == 'auth' && isset($_POST['login']) && isset($_POST['pass'])
if (isset($_POST['method']) && $_POST['method'] == 'auth' && isset($_POST['login']) && isset($_POST['pass'])){
        $pdo = connect();

        $sql = "SELECT `id` FROM " . DB_TABLE_USERS . " WHERE `login` = :login AND `pass` = :pass";

        $sth = $pdo->prepare($sql);

        try {

            $res = $sth->execute(

                array(

                    'login' => $_POST['login'], 

                    'pass' =>  md5($_POST['pass'])

                )

            );

            $row = $sth->fetch();

            if ($row == false) {

                echo '1001'; // Неверный логин/пароль

            }else{

                echo generateAuthToken($row['id']);

            }

        }catch (\Throwable $th) {

            echo $th->getMessage();

        }

}



// if ($_POST['method'] == 'newUser' && $_POST['login'] && $_POST['pass']){

//     $pdo = connect();

//     $sql = "INSERT INTO " . DB_TABLE_USERS . "(`fname`,`lname`,`login`,`pass`,`can_people_select`, `can_people_delete`, `can_people_insert`,`can_people_update`,`can_techins_select`,`can_techins_delete`,`can_techins_insert`,`can_techins_update`,`can_vehicle_select`,`can_vehicle_delete`,`can_vehicle_insert`,`can_vehicle_update`,`can_users_select`,`can_users_delete`,`can_users_insert`,`can_users_update`) VALUES (:fname,:lname, :login, :pass, :can_people_select, :can_people_delete, :can_people_insert, :can_people_update, :can_techins_select, :can_techins_delete, :can_techins_insert, :can_techins_update, :can_vehicle_select, :can_vehicle_delete, :can_vehicle_insert, :can_vehicle_update, :can_users_select, :can_users_delete, :can_users_insert, :can_users_update)";

//     $sth = $pdo->prepare($sql);

//     try {

//         $res = $sth->execute(

//             array(

//                 'fname' => 'admin', 

//                 'lname' => 'admin', 

//                 'login' => $_POST['login'], 

//                 'pass' =>  md5($_POST['pass']),

//                 'can_people_select' => 1,

//                 'can_people_delete' => 1,

//                 'can_people_insert' => 1,

//                 'can_people_update' => 1,

//                 'can_techins_select' => 1,

//                 'can_techins_delete' => 1,

//                 'can_techins_insert' => 1,

//                 'can_techins_update' => 1,

//                 'can_vehicle_select' => 1,

//                 'can_vehicle_delete' => 1,

//                 'can_vehicle_insert' => 1,

//                 'can_vehicle_update' => 1,

//                 'can_users_select' => 1,

//                 'can_users_delete' => 1,

//                 'can_users_insert' => 1,

//                 'can_users_update' => 1





                

//                 // 'fname' => $user['name'], 

//                 // 'lname' => isset($user['phone_number']) ? $user['phone_number'] : null, 

//                 // 'status' =>  $user['status'], 

//                 // 'login' =>  isset($user['permission']['can_view_personalLogs']) ? 1 : 0,

//                 // 'pass' =>  isset($user['permission']['can_view_personalLogs']) ? 1 : 0,

//                 // 'can_people_select' => isset($user['permission']['can_view_systemLogs']) ? 1 : 0,

//                 // 'can_people_delete' => isset($user['permission']['can_view_personal']) ? 1 : 0,

//                 // 'can_people_insert' => isset($user['permission']['can_edit_personal']) ? 1 : 0,

//                 // 'can_people_update' => isset($user['permission']['can_edit_menu']) ? 1 : 0,

//                 // 'can_techins_select' => isset($user['permission']['can_edit_info']) ? 1 : 0,

//                 // 'can_techins_delete' => isset($user['permission']['can_edit_promo']) ? 1 : 0,

//                 // 'can_techins_insert' => isset($user['permission']['can_edit_systems']) ? 1 : 0,

//                 // 'can_techins_update' => isset($user['permission']['can_edit_conflictMenu']) ? 1 : 0,

//                 // 'can_vehicle_select' => isset($user['permission']['can_view_personal']) ? 1 : 0,

//                 // 'can_vehicle_delete' => isset($user['permission']['can_edit_personal']) ? 1 : 0,

//                 // 'can_vehicle_insert' => isset($user['permission']['can_edit_menu']) ? 1 : 0,

//                 // 'can_vehicle_update' => isset($user['permission']['can_view_personal']) ? 1 : 0,

//                 // 'can_users_select' => isset($user['permission']['can_edit_personal']) ? 1 : 0,

//                 // 'can_users_delete' => isset($user['permission']['can_edit_menu']) ? 1 : 0,

//                 // 'can_users_insert' => isset($user['permission']['can_view_personal']) ? 1 : 0,

//                 // 'can_users_update' => isset($user['permission']['can_edit_personal']) ? 1 : 0

//             )

//         );

//         echo 1;

//     }catch (\Throwable $th) {

//         echo $th->getMessage();

//     }

// }









function connect(){



    try {



        $conn = new PDO('mysql:dbname=' . DB_NAME . ';host=' . DB_SERVER, DB_LOGIN, DB_PASS);



        $conn->exec("set names utf8mb4");



        $conn->exec("set character set utf8mb4");



        return $conn; 



    } catch (PDOException $exception) {




        return "Ошибка подключения к базе данных: " . $exception->getMessage();



    }



}



?>