#ifndef ADDUSERWINDOW_H
#define ADDUSERWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonObject>
#include <QJsonDocument>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QMessageBox>
#include <QString>
#include <QCheckBox>

namespace Ui {
class AddUserWindow;
}

class AddUserWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AddUserWindow(QWidget *parent = nullptr, const QString &token = "", int id = -1, const QString &name = "", const QString &lname = "", const QString &login = "", const QString &pass = "", const bool &cps = false, const bool &cpd = false, const bool &cpi = false, const bool &cpu = false, const bool &cts = false, const bool &ctd = false, const bool &cti = false, const bool &ctu = false, const bool &cvs = false, const bool &cvd = false, const bool &cvi = false, const bool &cvu = false, const bool &cus = false, const bool &cud = false, const bool &cui = false, const bool &cuu = false);
    ~AddUserWindow();

    void setWindowTitle(const QString &title);
    void setSubmitButtonText(const QString &text);

signals:
    void userAdded();

private slots:
    void onSubmitButtonClicked();
    void onNetworkReplyFinished();

private:
    Ui::AddUserWindow *ui;
    QString authToken;
    int userId;
    QNetworkAccessManager *networkManager;

    QLineEdit *idField;
    QLineEdit *nameField;
    QLineEdit *lnameField;
    QLineEdit *loginField;
    QLineEdit *passField;
    QCheckBox *cpsField;
    QCheckBox *cpdField;
    QCheckBox *cpiField;
    QCheckBox *cpuField;
    QCheckBox *ctsField;
    QCheckBox *ctdField;
    QCheckBox *ctiField;
    QCheckBox *ctuField;
    QCheckBox *cvsField;
    QCheckBox *cvdField;
    QCheckBox *cviField;
    QCheckBox *cvuField;
    QCheckBox *cusField;
    QCheckBox *cudField;
    QCheckBox *cuiField;
    QCheckBox *cuuField;

    QPushButton *submitButton;
};

#endif // ADDUSERWINDOW_H
