/********************************************************************************
** Form generated from reading UI file 'addpeoplewindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.16
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDPEOPLEWINDOW_H
#define UI_ADDPEOPLEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddPeopleWindow
{
public:

    void setupUi(QWidget *AddPeopleWindow)
    {
        if (AddPeopleWindow->objectName().isEmpty())
            AddPeopleWindow->setObjectName(QString::fromUtf8("AddPeopleWindow"));
        AddPeopleWindow->resize(400, 300);

        retranslateUi(AddPeopleWindow);

        QMetaObject::connectSlotsByName(AddPeopleWindow);
    } // setupUi

    void retranslateUi(QWidget *AddPeopleWindow)
    {
        AddPeopleWindow->setWindowTitle(QCoreApplication::translate("AddPeopleWindow", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddPeopleWindow: public Ui_AddPeopleWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDPEOPLEWINDOW_H
