/********************************************************************************
** Form generated from reading UI file 'addvehiclewindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.16
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDVEHICLEWINDOW_H
#define UI_ADDVEHICLEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddVehicleWindow
{
public:

    void setupUi(QWidget *AddVehicleWindow)
    {
        if (AddVehicleWindow->objectName().isEmpty())
            AddVehicleWindow->setObjectName(QString::fromUtf8("AddVehicleWindow"));
        AddVehicleWindow->resize(400, 300);

        retranslateUi(AddVehicleWindow);

        QMetaObject::connectSlotsByName(AddVehicleWindow);
    } // setupUi

    void retranslateUi(QWidget *AddVehicleWindow)
    {
        AddVehicleWindow->setWindowTitle(QCoreApplication::translate("AddVehicleWindow", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddVehicleWindow: public Ui_AddVehicleWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDVEHICLEWINDOW_H
