/********************************************************************************
** Form generated from reading UI file 'secondaryWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.16
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SECONDARYWINDOW_H
#define UI_SECONDARYWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SecondaryWindow
{
public:
    QPushButton *pushButton_vehicles;
    QPushButton *pushButton_people;
    QPushButton *pushButton_techins;
    QPushButton *pushButton_users;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QWidget *SecondaryWindow)
    {
        if (SecondaryWindow->objectName().isEmpty())
            SecondaryWindow->setObjectName(QString::fromUtf8("SecondaryWindow"));
        SecondaryWindow->resize(290, 300);
        SecondaryWindow->setMinimumSize(QSize(290, 300));
        SecondaryWindow->setMaximumSize(QSize(290, 300));
        pushButton_vehicles = new QPushButton(SecondaryWindow);
        pushButton_vehicles->setObjectName(QString::fromUtf8("pushButton_vehicles"));
        pushButton_vehicles->setGeometry(QRect(70, 112, 141, 31));
        pushButton_people = new QPushButton(SecondaryWindow);
        pushButton_people->setObjectName(QString::fromUtf8("pushButton_people"));
        pushButton_people->setGeometry(QRect(70, 190, 141, 31));
        pushButton_techins = new QPushButton(SecondaryWindow);
        pushButton_techins->setObjectName(QString::fromUtf8("pushButton_techins"));
        pushButton_techins->setGeometry(QRect(70, 150, 141, 31));
        pushButton_users = new QPushButton(SecondaryWindow);
        pushButton_users->setObjectName(QString::fromUtf8("pushButton_users"));
        pushButton_users->setGeometry(QRect(70, 230, 141, 31));
        label = new QLabel(SecondaryWindow);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(60, 10, 171, 20));
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(SecondaryWindow);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 30, 271, 20));
        label_2->setAlignment(Qt::AlignCenter);

        retranslateUi(SecondaryWindow);

        QMetaObject::connectSlotsByName(SecondaryWindow);
    } // setupUi

    void retranslateUi(QWidget *SecondaryWindow)
    {
        SecondaryWindow->setWindowTitle(QCoreApplication::translate("SecondaryWindow", "\320\234\320\265\320\275\321\216", nullptr));
        pushButton_vehicles->setText(QCoreApplication::translate("SecondaryWindow", "\320\220\320\262\321\202\320\276\320\274\320\276\320\261\320\270\320\273\320\270", nullptr));
        pushButton_people->setText(QCoreApplication::translate("SecondaryWindow", "\320\233\321\216\320\264\320\270", nullptr));
        pushButton_techins->setText(QCoreApplication::translate("SecondaryWindow", "\320\242\320\265\321\205.\320\276\321\201\320\274\320\276\321\202\321\200\321\213", nullptr));
        pushButton_users->setText(QCoreApplication::translate("SecondaryWindow", "\320\241\320\276\321\202\321\200\321\203\320\264\320\275\320\270\320\272\320\270", nullptr));
        label->setText(QCoreApplication::translate("SecondaryWindow", "\320\227\320\264\321\200\320\260\320\262\321\201\321\202\320\262\321\203\320\271\321\202\320\265", nullptr));
        label_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class SecondaryWindow: public Ui_SecondaryWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SECONDARYWINDOW_H
