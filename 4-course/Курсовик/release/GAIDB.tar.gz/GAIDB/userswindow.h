#ifndef USERSWINDOW_H
#define USERSWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QTableView>
#include <QPushButton>
#include <QVBoxLayout>
#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonArray>
#include <QStandardItemModel>
#include <QMessageBox>

namespace Ui {
class UsersWindow;
}

class UsersWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit UsersWindow(QWidget *parent = nullptr, const QString &token = "", const QJsonObject &userPermissions = QJsonObject());
    ~UsersWindow();

private slots:
    void onAddButtonClicked();
    void onEditButtonClicked();
    void onDeleteButtonClicked();
    void updateTable();
    void onNetworkReplyFinished();
    void onDeleteNetworkReplyFinished();

private:
    Ui::UsersWindow *ui;
    QString authToken;
    QJsonObject permissions;
    QNetworkAccessManager *networkManager;
    QTableView *tableView;
    QPushButton *addButton;
    QPushButton *editButton;
    QPushButton *deleteButton;
};

#endif // USERSWINDOW_H
