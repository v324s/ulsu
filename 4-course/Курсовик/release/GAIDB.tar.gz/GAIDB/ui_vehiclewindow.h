/********************************************************************************
** Form generated from reading UI file 'vehiclewindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.16
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VEHICLEWINDOW_H
#define UI_VEHICLEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_VehicleWindow
{
public:

    void setupUi(QWidget *VehicleWindow)
    {
        if (VehicleWindow->objectName().isEmpty())
            VehicleWindow->setObjectName(QString::fromUtf8("VehicleWindow"));
        VehicleWindow->resize(400, 300);

        retranslateUi(VehicleWindow);

        QMetaObject::connectSlotsByName(VehicleWindow);
    } // setupUi

    void retranslateUi(QWidget *VehicleWindow)
    {
        VehicleWindow->setWindowTitle(QCoreApplication::translate("VehicleWindow", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class VehicleWindow: public Ui_VehicleWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VEHICLEWINDOW_H
