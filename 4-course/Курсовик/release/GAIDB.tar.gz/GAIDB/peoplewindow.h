#ifndef PEOPLEWINDOW_H
#define PEOPLEWINDOW_H

#include <QWidget>
#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QStandardItemModel>
#include <QTableView>
#include <QPushButton>
#include <QVBoxLayout>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QMessageBox>

namespace Ui {
class PeopleWindow;
}

class PeopleWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit PeopleWindow(QWidget *parent = nullptr, const QString &token = "", const QJsonObject &userPermissions = QJsonObject());
    ~PeopleWindow();

private slots:
    void onAddButtonClicked();
    void onDeleteButtonClicked();
    void onEditButtonClicked();
    void onNetworkReplyFinished();
    void updateTable();
    void onDeleteNetworkReplyFinished();

private:
    Ui::PeopleWindow *ui;
    QString authToken;
    QJsonObject permissions;
    QNetworkAccessManager *networkManager;

    QTableView *tableView;
    QPushButton *addButton;
    QPushButton *deleteButton;
    QPushButton *editButton;
};

#endif // PEOPLEWINDOW_H
