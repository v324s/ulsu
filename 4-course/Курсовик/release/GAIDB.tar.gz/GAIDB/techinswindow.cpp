#include "techinswindow.h"
#include "ui_techinswindow.h"
#include "addtechinswindow.h" // Добавляем форму для добавления записи

#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QHeaderView>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QStandardItemModel>
#include <QFormLayout>
#include <QVBoxLayout>

TechinsWindow::TechinsWindow(QWidget *parent, const QString &token, const QJsonObject &userPermissions) :
    QMainWindow(parent),
    ui(new Ui::TechinsWindow),
    authToken(token),
    permissions(userPermissions),
    networkManager(new QNetworkAccessManager(this))
{
    ui->setupUi(this);

    // Инициализация виджетов
    tableView = new QTableView(this);
    addButton = new QPushButton("Добавить", this);
    deleteButton = new QPushButton("Удалить", this);
    editButton = new QPushButton("Изменить", this);

    // Установка прав доступа
    addButton->setEnabled(permissions.value("can_vehicle_insert").toInt() == 1);
    deleteButton->setEnabled(permissions.value("can_vehicle_delete").toInt() == 1);
    editButton->setEnabled(permissions.value("can_vehicle_update").toInt() == 1);

    // Размещение виджетов
    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(tableView);
    layout->addWidget(addButton);
    layout->addWidget(deleteButton);
    layout->addWidget(editButton);

    QWidget *container = new QWidget;
    container->setLayout(layout);
    setCentralWidget(container);

    // Подключение слотов к кнопкам
    connect(addButton, &QPushButton::clicked, this, &TechinsWindow::onAddButtonClicked);
    connect(deleteButton, &QPushButton::clicked, this, &TechinsWindow::onDeleteButtonClicked);
    connect(editButton, &QPushButton::clicked, this, &TechinsWindow::onEditButtonClicked);

    // Выполнение запроса к API для получения данных
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

    QJsonObject postData;
    postData["method"] = "getTechins";

    QNetworkReply *reply = networkManager->post(request, QJsonDocument(postData).toJson());
    connect(reply, &QNetworkReply::finished, this, &TechinsWindow::onNetworkReplyFinished);
}

TechinsWindow::~TechinsWindow()
{
    delete ui;
}

void TechinsWindow::onAddButtonClicked()
{
    AddTechinsWindow *addWindow = new AddTechinsWindow(this, authToken);
    connect(addWindow, &AddTechinsWindow::techinsAdded, this, &TechinsWindow::updateTable);
    addWindow->show();
}

void TechinsWindow::onDeleteButtonClicked()
{
    QModelIndexList selectedRows = tableView->selectionModel()->selectedRows();
    if (selectedRows.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, выберите строку для удаления.");
        return;
    }

    int selectedRow = selectedRows.first().row();
    QStandardItemModel *model = qobject_cast<QStandardItemModel*>(tableView->model());
    if (!model) {
        QMessageBox::warning(this, "Ошибка", "Невозможно получить модель данных.");
        return;
    }

    int id = model->item(selectedRow, 0)->text().toInt();

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Удаление", "Вы уверены, что хотите удалить строку #" + QString::number(id) + "?",
                                  QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
        request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

        QJsonObject postData;
        postData["method"] = "deleteTechins";
        postData["id"] = id;

        QNetworkReply *networkReply = networkManager->post(request, QJsonDocument(postData).toJson());
        connect(networkReply, &QNetworkReply::finished, this, &TechinsWindow::onDeleteNetworkReplyFinished);
    }
}

void TechinsWindow::onEditButtonClicked()
{
    QModelIndexList selectedRows = tableView->selectionModel()->selectedRows();
    if (selectedRows.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, выберите строку для редактирования.");
        return;
    }

    int selectedRow = selectedRows.first().row();
    QStandardItemModel *model = qobject_cast<QStandardItemModel*>(tableView->model());
    if (!model) {
        QMessageBox::warning(this, "Ошибка", "Невозможно получить модель данных.");
        return;
    }

    int id = model->item(selectedRow, 0)->text().toInt();
    QString date = model->item(selectedRow, 1)->text();
    QString vehicleId = model->item(selectedRow, 2)->text();
    QString mileage = model->item(selectedRow, 6)->text();
    QString status = model->item(selectedRow, 7)->text();

    AddTechinsWindow *editWindow = new AddTechinsWindow(this, authToken, id, date, vehicleId, mileage, status);
    editWindow->setWindowTitle("Редактировать запись");
    //editWindow->setSubmitButtonText("Изменить");
    connect(editWindow, &AddTechinsWindow::techinsAdded, this, &TechinsWindow::updateTable);
    editWindow->show();
}

void TechinsWindow::updateTable()
{
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8());

    QJsonObject postData;
    postData["method"] = "getTechins";

    QNetworkReply *reply = networkManager->post(request, QJsonDocument(postData).toJson());
    connect(reply, &QNetworkReply::finished, this, &TechinsWindow::onNetworkReplyFinished);
}

void TechinsWindow::onNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (reply->error() == QNetworkReply::NoError) {
        QByteArray response = reply->readAll();
        QJsonDocument jsonResponse = QJsonDocument::fromJson(response);
        QJsonArray jsonArray = jsonResponse.array();

        QStandardItemModel *model = new QStandardItemModel(jsonArray.size(), 8, this);
        model->setHeaderData(0, Qt::Horizontal, "№ стр.");
        model->setHeaderData(1, Qt::Horizontal, "Дата");
        model->setHeaderData(2, Qt::Horizontal, "ID Автомобиля");
        model->setHeaderData(3, Qt::Horizontal, "Производитель");
        model->setHeaderData(4, Qt::Horizontal, "Модель");
        model->setHeaderData(5, Qt::Horizontal, "№ кузова");
        model->setHeaderData(6, Qt::Horizontal, "Пробег");
        model->setHeaderData(7, Qt::Horizontal, "Статус");

        for (int i = 0; i < jsonArray.size(); ++i) {
            QJsonObject jsonObject = jsonArray[i].toObject();
            model->setItem(i, 0, new QStandardItem(QString::number(jsonObject["id"].toInt())));
            model->setItem(i, 1, new QStandardItem(jsonObject["date"].toString()));
            model->setItem(i, 2, new QStandardItem(QString::number(jsonObject["vehicle_id"].toInt())));
            model->setItem(i, 3, new QStandardItem(jsonObject["vehicle_make"].toString()));
            model->setItem(i, 4, new QStandardItem(jsonObject["vehicle_model"].toString()));
            model->setItem(i, 5, new QStandardItem(jsonObject["vehicle_number_body"].toString()));
            model->setItem(i, 6, new QStandardItem(QString::number(jsonObject["mileage"].toInt())));
            model->setItem(i, 7, new QStandardItem(jsonObject["status"].toString()));
        }

        tableView->setModel(model);
    } else {
        QMessageBox::warning(this, "Ошибка", "Не удалось получить данные: " + reply->errorString());
    }
    reply->deleteLater();
}


void TechinsWindow::onDeleteNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (reply->error() == QNetworkReply::NoError) {
        QMessageBox::information(this, "Успех", "Запись успешно удалена.");
        updateTable();
    } else {
        QMessageBox::warning(this, "Ошибка", "Не удалось удалить запись: " + reply->errorString());
    }
    reply->deleteLater();
}
