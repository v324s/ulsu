#ifndef VEHICLEWINDOW_H
#define VEHICLEWINDOW_H

#include <QMainWindow>
#include <QTableView>
#include <QPushButton>
#include <QVBoxLayout>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QStandardItemModel>
#include <QMessageBox>

namespace Ui {
class VehicleWindow;
}

class VehicleWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit VehicleWindow(QWidget *parent = nullptr, const QString &token = "", const QJsonObject &userPermissions = QJsonObject());
    ~VehicleWindow();

private slots:
    void onAddButtonClicked();
    void onDeleteButtonClicked();
    void onEditButtonClicked();
    void onNetworkReplyFinished();
    void updateTable();
    void onDeleteNetworkReplyFinished();

private:
    Ui::VehicleWindow *ui;
    QString authToken;
    QJsonObject permissions;
    QNetworkAccessManager *networkManager;

    QTableView *tableView;
    QPushButton *addButton;
    QPushButton *deleteButton;
    QPushButton *editButton;
};

#endif // VEHICLEWINDOW_H
