/********************************************************************************
** Form generated from reading UI file 'techinswindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.16
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TECHINSWINDOW_H
#define UI_TECHINSWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TechinsWindow
{
public:

    void setupUi(QWidget *TechinsWindow)
    {
        if (TechinsWindow->objectName().isEmpty())
            TechinsWindow->setObjectName(QString::fromUtf8("TechinsWindow"));
        TechinsWindow->resize(400, 300);

        retranslateUi(TechinsWindow);

        QMetaObject::connectSlotsByName(TechinsWindow);
    } // setupUi

    void retranslateUi(QWidget *TechinsWindow)
    {
        TechinsWindow->setWindowTitle(QCoreApplication::translate("TechinsWindow", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class TechinsWindow: public Ui_TechinsWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TECHINSWINDOW_H
