/********************************************************************************
** Form generated from reading UI file 'addtechinswindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.16
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDTECHINSWINDOW_H
#define UI_ADDTECHINSWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddTechinsWindow
{
public:

    void setupUi(QWidget *AddTechinsWindow)
    {
        if (AddTechinsWindow->objectName().isEmpty())
            AddTechinsWindow->setObjectName(QString::fromUtf8("AddTechinsWindow"));
        AddTechinsWindow->resize(400, 300);

        retranslateUi(AddTechinsWindow);

        QMetaObject::connectSlotsByName(AddTechinsWindow);
    } // setupUi

    void retranslateUi(QWidget *AddTechinsWindow)
    {
        AddTechinsWindow->setWindowTitle(QCoreApplication::translate("AddTechinsWindow", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddTechinsWindow: public Ui_AddTechinsWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDTECHINSWINDOW_H
