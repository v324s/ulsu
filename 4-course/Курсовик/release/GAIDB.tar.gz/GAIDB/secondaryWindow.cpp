#include "secondaryWindow.h"
#include "ui_secondaryWindow.h"
#include "techinswindow.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QDebug>

SecondaryWindow::SecondaryWindow(QWidget *parent, const QString &token) :
    QMainWindow(parent),
    ui(new Ui::SecondaryWindow),
    authToken(token),
    networkManager(new QNetworkAccessManager(this))
{
    ui->setupUi(this);

    // Параметры запроса
    QJsonObject requestData;
    requestData["method"] = "getMe";

    // Создание JSON-документа из параметров запроса
    QJsonDocument requestDoc(requestData);
    QByteArray requestDataByteArray = requestDoc.toJson();

    // Отправка запроса на API при загрузке формы
    QNetworkRequest request(QUrl("http://gvev.ru/ulsu/api/engine"));
    request.setRawHeader("Authorization", ("Bearer " + authToken).toUtf8());
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

//    QNetworkReply *reply = networkManager->get(request);
    QNetworkReply *reply = networkManager->post(request, requestDataByteArray);
    connect(reply, &QNetworkReply::finished, this, &SecondaryWindow::onNetworkReplyFinished);

    // Подключение слота к кнопке "Автомобили"
    connect(ui->pushButton_vehicles, &QPushButton::clicked, this, &SecondaryWindow::onVehicleButtonClicked);
    connect(ui->pushButton_techins, &QPushButton::clicked, this, &SecondaryWindow::onTechinsButtonClicked);
    connect(ui->pushButton_people, &QPushButton::clicked, this, &SecondaryWindow::onPeopleButtonClicked);
    connect(ui->pushButton_users, &QPushButton::clicked, this, &SecondaryWindow::onUsersButtonClicked);
}

SecondaryWindow::~SecondaryWindow()
{
    delete ui;
}



void SecondaryWindow::onNetworkReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (reply->error() == QNetworkReply::NoError) {
        QByteArray responseData = reply->readAll();

        //QString responseString(responseData);

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        QJsonObject jsonObject = jsonDoc.object();

        userPermissions = jsonObject;

        // Установка значений "fname" и "lname" в label_2
        QString fullName = jsonObject.value("fname").toString() + " " + jsonObject.value("lname").toString();
        ui->label_2->setText(fullName);

        // Проверка доступности кнопок и их установка в соответствии с JSON
        setButtonAvailability(jsonObject.value("can_vehicle_select").toInt(), ui->pushButton_vehicles);
        setButtonAvailability(jsonObject.value("can_people_select").toInt(), ui->pushButton_people);
        setButtonAvailability(jsonObject.value("can_techins_select").toInt(), ui->pushButton_techins);
        setButtonAvailability(jsonObject.value("can_users_select").toInt(), ui->pushButton_users);

    } else {
        QMessageBox msgBox;
        msgBox.setText("Ошибка:" + reply->errorString());
        msgBox.exec();
//        qDebug() << "Ошибка при получении данных:" << reply->errorString();
    }

    reply->deleteLater();
}

void SecondaryWindow::setButtonAvailability(int value, QPushButton *button)
{
    if (value == 1) {
        button->setEnabled(true);
    } else {
        button->setEnabled(false);
    }
}

void SecondaryWindow::onVehicleButtonClicked()
{
    VehicleWindow *vehicleWindow = new VehicleWindow(this, authToken, userPermissions);
    vehicleWindow->setWindowTitle("Автомобили");
    vehicleWindow->show();
}

void SecondaryWindow::onTechinsButtonClicked()
{
    TechinsWindow *techinsWindow = new TechinsWindow(this, authToken, userPermissions);
    techinsWindow->setWindowTitle("Тех.осмотры");
    techinsWindow->show();
}

void SecondaryWindow::onPeopleButtonClicked()
{
    PeopleWindow *peopleWindow = new PeopleWindow(this, authToken, userPermissions);
    peopleWindow->setWindowTitle("Люди");
    peopleWindow->show();
}

void SecondaryWindow::onUsersButtonClicked()
{
    UsersWindow *usersWindow = new UsersWindow(this, authToken, userPermissions);
    usersWindow->setWindowTitle("Пользователи");
    usersWindow->show();
}
