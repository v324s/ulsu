#ifndef ADDTECHINSWINDOW_H
#define ADDTECHINSWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QLineEdit>
#include <QPushButton>

namespace Ui {
class AddTechinsWindow;
}

class AddTechinsWindow : public QMainWindow
{
    Q_OBJECT

public:
    // explicit AddTechinsWindow(QWidget *parent = nullptr, const QString &token = QString(), int id = -1, const QString &date = QString(),
    //                           const QString &make = QString(), const QString &vehicleModel = QString(), const QString &number = QString(), const QString &status = QString());
    // ~AddTechinsWindow();

    // void setSubmitButtonText(const QString &text);

    explicit AddTechinsWindow(QWidget *parent = nullptr, const QString &token = "", int id = -1, const QString &date = "", const QString &vehicleId = "", const QString &mileage = "", const QString &status = "");
    ~AddTechinsWindow();

signals:
    void techinsAdded();

private slots:
    void onSubmitButtonClicked();
    void onNetworkReplyFinished();

private:
    Ui::AddTechinsWindow *ui;
    QString authToken;
    int techinsId;
    QNetworkAccessManager *networkManager;
    QLineEdit *dateEdit;
    QLineEdit *vehicleIdEdit;
    QLineEdit *mileageEdit;
    QLineEdit *statusEdit;
    QPushButton *submitButton;
};

#endif // ADDTECHINSWINDOW_H
